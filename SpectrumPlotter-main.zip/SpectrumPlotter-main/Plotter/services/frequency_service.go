// services/frequency_service.go
package services

import (
	"fmt"
	"sfaf-plotter/models"
	"sfaf-plotter/repositories"
	"time"

	"github.com/google/uuid"
)

type FrequencyService struct {
	repo        *repositories.FrequencyRepository
	userRepo    *repositories.UserRepository
	installRepo *repositories.InstallationRepository
}

func NewFrequencyService(repo *repositories.FrequencyRepository, userRepo *repositories.UserRepository, installRepo *repositories.InstallationRepository) *FrequencyService {
	return &FrequencyService{repo: repo, userRepo: userRepo, installRepo: installRepo}
}

var roleLevels = map[string]int{
	"operator":          1,
	"ism":               2,
	"command":           3,
	"combatant_command": 4,
	"agency":            5,
	"ntia":              6,
	"admin":             7,
}

// ============================================
// Unit Management
// ============================================

func (s *FrequencyService) CreateUnit(input *models.Unit) (*models.Unit, error) {
	// Validate unit code is unique
	existing, _ := s.repo.GetUnitByCode(input.UnitCode)
	if existing != nil {
		return nil, fmt.Errorf("unit code already exists: %s", input.UnitCode)
	}

	input.IsActive = true
	err := s.repo.CreateUnit(input)
	if err != nil {
		return nil, fmt.Errorf("failed to create unit: %w", err)
	}

	return input, nil
}

// UpdateUnit updates an existing unit
func (s *FrequencyService) UpdateUnit(input *models.Unit) (*models.Unit, error) {
	// Check if unit exists
	existing, err := s.repo.GetUnitByID(input.ID)
	if err != nil {
		return nil, fmt.Errorf("unit not found: %w", err)
	}

	// If unit code is being changed, check it's unique
	if input.UnitCode != existing.UnitCode {
		codeCheck, _ := s.repo.GetUnitByCode(input.UnitCode)
		if codeCheck != nil {
			return nil, fmt.Errorf("unit code already exists: %s", input.UnitCode)
		}
	}

	err = s.repo.UpdateUnit(input)
	if err != nil {
		return nil, fmt.Errorf("failed to update unit: %w", err)
	}

	return input, nil
}

// DeleteUnit deletes a unit
func (s *FrequencyService) DeleteUnit(unitID uuid.UUID) error {
	// Check if unit has active frequency assignments
	assignments, err := s.repo.GetUnitFrequencyAssignments(unitID)
	if err != nil {
		return fmt.Errorf("failed to check unit assignments: %w", err)
	}

	if len(assignments) > 0 {
		return fmt.Errorf("cannot delete unit with active frequency assignments")
	}

	err = s.repo.DeleteUnit(unitID)
	if err != nil {
		return fmt.Errorf("failed to delete unit: %w", err)
	}

	return nil
}

func (s *FrequencyService) GetUserUnitsWithAssignments(userID uuid.UUID) ([]models.UnitWithAssignments, error) {
	units, err := s.repo.GetUserUnits(userID)
	if err != nil {
		return nil, err
	}

	result := make([]models.UnitWithAssignments, 0, len(units))
	for _, unit := range units {
		assignments, err := s.repo.GetUnitFrequencyAssignments(unit.ID)
		if err != nil {
			return nil, err
		}

		// Get pending requests for this unit
		unitRequests, err := s.repo.GetUnitFrequencyRequests(unit.ID)
		if err != nil {
			return nil, err
		}

		pendingRequests := make([]models.FrequencyRequest, 0)
		for _, req := range unitRequests {
			if req.Status == "pending" || req.Status == "under_review" {
				pendingRequests = append(pendingRequests, req)
			}
		}

		// Get member count
		members, _ := s.repo.GetUnitMembers(unit.ID)

		result = append(result, models.UnitWithAssignments{
			Unit:                 &unit,
			FrequencyAssignments: assignments,
			PendingRequests:      pendingRequests,
			MemberCount:          len(members),
		})
	}

	return result, nil
}

func (s *FrequencyService) GetMajcomUnits() ([]models.Unit, error) {
	return s.repo.GetMajcomUnits()
}

func (s *FrequencyService) GetSubordinateUnits(parentUnitID uuid.UUID) ([]models.Unit, error) {
	return s.repo.GetSubordinateUnits(parentUnitID)
}

func (s *FrequencyService) GetAllUnitsWithAssignments() ([]models.UnitWithAssignments, error) {
	units, err := s.repo.GetAllUnits()
	if err != nil {
		return nil, err
	}

	result := make([]models.UnitWithAssignments, 0, len(units))
	for _, unit := range units {
		assignments, err := s.repo.GetUnitFrequencyAssignments(unit.ID)
		if err != nil {
			return nil, err
		}

		// Get pending requests for this unit
		unitRequests, err := s.repo.GetUnitFrequencyRequests(unit.ID)
		if err != nil {
			return nil, err
		}

		pendingRequests := make([]models.FrequencyRequest, 0)
		for _, req := range unitRequests {
			if req.Status == "pending" || req.Status == "under_review" {
				pendingRequests = append(pendingRequests, req)
			}
		}

		// Get member count
		members, _ := s.repo.GetUnitMembers(unit.ID)

		result = append(result, models.UnitWithAssignments{
			Unit:                 &unit,
			FrequencyAssignments: assignments,
			PendingRequests:      pendingRequests,
			MemberCount:          len(members),
		})
	}

	return result, nil
}

// ============================================
// Frequency Assignment Management
// ============================================

func (s *FrequencyService) CreateFrequencyAssignment(
	input *models.CreateFrequencyAssignmentInput,
	createdBy uuid.UUID,
) (*models.FrequencyAssignment, error) {
	// Validate unit exists
	_, err := s.repo.GetUnitByID(input.UnitID)
	if err != nil {
		return nil, fmt.Errorf("unit not found: %w", err)
	}

	// strPtr converts empty strings to nil (stored as NULL)
	strPtr := func(s string) *string {
		if s == "" {
			return nil
		}
		return &s
	}
	// defaultStr returns fallback when s is empty
	defaultStr := func(s, fallback string) string {
		if s == "" {
			return fallback
		}
		return s
	}
	_ = defaultStr // used below

	// Default sfaf_record_type to 'A' if not supplied
	recordType := input.SFAFRecordType
	if recordType == "" {
		recordType = "A"
	}

	// Resolve initial edit authority from creator's primary workbox.
	var editAuthorityWorkbox *string
	if name, err := s.repo.GetUserPrimaryWorkboxName(createdBy); err == nil {
		editAuthorityWorkbox = name
	}

	// Create assignment
	assignment := &models.FrequencyAssignment{
		UnitID:               input.UnitID,
		Serial:               strPtr(input.Serial),
		SFAFRecordType:       recordType,
		Frequency:            input.Frequency,
		FrequencyMhz:         input.FrequencyMhz,
		AssignmentType:       input.AssignmentType,
		Purpose:              strPtr(input.Purpose),
		NetName:              strPtr(input.NetName),
		Callsign:             strPtr(input.Callsign),
		EmissionDesignator:   strPtr(input.EmissionDesignator),
		Bandwidth:            strPtr(input.Bandwidth),
		PowerWatts:           input.PowerWatts,
		AuthorizedRadiusKm:   input.AuthorizedRadiusKm,
		AssignmentDate:       input.AssignmentDate,
		ExpirationDate:       input.ExpirationDate,
		AssignmentAuthority:  strPtr(input.AssignmentAuthority),
		AuthorizationNumber:  strPtr(input.AuthorizationNumber),
		Priority:             defaultStr(input.Priority, "routine"),
		IsEncrypted:          input.IsEncrypted,
		EncryptionType:       strPtr(input.EncryptionType),
		Classification:       input.Classification,
		Notes:                strPtr(input.Notes),
		IsActive:             true,
		CreatedBy:            &createdBy,
		RoutedToWorkbox:      input.RoutedToWorkbox,
		EditAuthorityWorkbox: editAuthorityWorkbox,
		PoolSerial:           strPtr(input.PoolSerial),
	}

	err = s.repo.CreateFrequencyAssignment(assignment)
	if err != nil {
		return nil, fmt.Errorf("failed to create frequency assignment: %w", err)
	}

	statusCode := "ORIGINATED BY"
	if recordType == "A" || recordType == "T" {
		statusCode = "ASSIGNED BY"
	}
	s.LogAssignmentEvent(assignment.ID, &createdBy, statusCode, "", "")
	return assignment, nil
}

func (s *FrequencyService) GetUserFrequencyAssignments(userID uuid.UUID) ([]models.FrequencyAssignmentWithDetails, error) {
	assignments, err := s.repo.GetUserUnitFrequencyAssignments(userID)
	if err != nil {
		return nil, err
	}

	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, assignment := range assignments {
		unit, _ := s.repo.GetUnitByID(assignment.UnitID)

		result = append(result, models.FrequencyAssignmentWithDetails{
			Assignment: &assignment,
			Unit:       unit,
		})
	}

	return result, nil
}

func (s *FrequencyService) GetExpiringFrequencies(days int) ([]models.FrequencyAssignmentWithDetails, error) {
	assignments, err := s.repo.GetExpiringAssignments(days)
	if err != nil {
		return nil, err
	}

	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, assignment := range assignments {
		unit, _ := s.repo.GetUnitByID(assignment.UnitID)

		result = append(result, models.FrequencyAssignmentWithDetails{
			Assignment: &assignment,
			Unit:       unit,
		})
	}

	return result, nil
}

// ============================================
// Frequency Request Management
// ============================================

func (s *FrequencyService) SubmitFrequencyRequest(
	input *models.CreateFrequencyRequestInput,
	requestedBy uuid.UUID,
) (*models.FrequencyRequest, error) {
	// Validate unit exists and user has access
	_, err := s.repo.GetUnitByID(input.UnitID)
	if err != nil {
		return nil, fmt.Errorf("unit not found: %w", err)
	}

	// Validate start date is not in the past
	if input.StartDate.Before(time.Now().Truncate(24 * time.Hour)) {
		return nil, fmt.Errorf("start date cannot be in the past")
	}

	// strPtr converts a non-empty string to a pointer; empty string becomes nil (stored as NULL).
	strPtr := func(s string) *string {
		if s == "" {
			return nil
		}
		return &s
	}

	// Resolve edit authority workbox.
	// Priority:
	//   1. ism_office as a workbox name (string, not a UUID)
	//   2. ism_office as an installation UUID → look up the installation's workbox
	//   3. requester's own primary workbox
	var editAuthorityWorkbox *string
	if input.ISMOffice != "" {
		if installID, parseErr := uuid.Parse(input.ISMOffice); parseErr != nil {
			// Not a UUID — treat as a direct workbox/ISM unit name
			editAuthorityWorkbox = &input.ISMOffice
		} else {
			// Installation UUID — resolve to the workbox linked to that installation
			editAuthorityWorkbox, _ = s.repo.GetWorkboxNameByInstallation(installID)
		}
	}
	if editAuthorityWorkbox == nil {
		if name, ismErr := s.repo.GetUserPrimaryWorkboxName(requestedBy); ismErr == nil {
			editAuthorityWorkbox = name
		}
	}

	// Create request
	request := &models.FrequencyRequest{
		UnitID:               input.UnitID,
		RequestedBy:          requestedBy,
		RequestType:          input.RequestType,
		Status:               "pending",
		Priority:             input.Priority,
		RequestedFrequency:   strPtr(input.RequestedFrequency),
		FrequencyRangeMin:    input.FrequencyRangeMin,
		FrequencyRangeMax:    input.FrequencyRangeMax,
		Purpose:              input.Purpose,
		NetName:              strPtr(input.NetName),
		Callsign:             strPtr(input.Callsign),
		AssignmentType:       strPtr(input.AssignmentType),
		EmissionDesignator:   strPtr(input.EmissionDesignator),
		Bandwidth:            strPtr(input.Bandwidth),
		PowerWatts:           input.PowerWatts,
		AntennaMakeModel:     strPtr(input.AntennaMakeModel),
		AntennaType:          strPtr(input.AntennaType),
		AntennaGainDbi:       input.AntennaGainDbi,
		AntennaPolarization:  strPtr(input.AntennaPolarization),
		AntennaOrientation:   strPtr(input.AntennaOrientation),
		TxHorizBeamwidthDeg: input.TxHorizBeamwidthDeg,
		TxVertBeamwidthDeg:  input.TxVertBeamwidthDeg,
		RxHorizBeamwidthDeg: input.RxHorizBeamwidthDeg,
		RxVertBeamwidthDeg:  input.RxVertBeamwidthDeg,
		CoverageArea:              strPtr(input.CoverageArea),
		OperatingAreaGeoJSON:      input.OperatingAreaGeoJSON,
		AuthorizedRadiusKm:        input.AuthorizedRadiusKm,
		OperatingAreaAppliesTo:    input.OperatingAreaAppliesTo,
		StartDate:            input.StartDate,
		EndDate:              input.EndDate,
		HoursOfOperation:     strPtr(input.HoursOfOperation),
		NumTransmitters:      input.NumTransmitters,
		NumReceivers:         input.NumReceivers,
		IsEncrypted:          input.IsEncrypted,
		EncryptionType:       strPtr(input.EncryptionType),
		Classification:       input.Classification,
		RequiresCoordination: input.RequiresCoordination,
		CoordinationNotes:    strPtr(input.CoordinationNotes),
		Justification:        input.Justification,
		StopBuzzer:           strPtr(input.StopBuzzer),
		MissionImpact:        strPtr(input.MissionImpact),
		RoutedToWorkbox:      editAuthorityWorkbox,
		EditAuthorityWorkbox: editAuthorityWorkbox,
	}

	err = s.repo.CreateFrequencyRequest(request)
	if err != nil {
		return nil, fmt.Errorf("failed to create frequency request: %w", err)
	}

	s.LogRequestEvent(request.ID, &requestedBy, "ORIGINATED BY", "", "")
	return request, nil
}

func (s *FrequencyService) ReviewFrequencyRequest(
	requestID uuid.UUID,
	reviewedBy uuid.UUID,
	status string,
	notes string,
) (*models.FrequencyRequest, error) {
	// Validate status
	validStatuses := map[string]bool{
		"under_review": true,
		"approved":     true,
		"denied":       true,
	}
	if !validStatuses[status] {
		return nil, fmt.Errorf("invalid status: %s", status)
	}

	// Get existing request
	_, err := s.repo.GetFrequencyRequestByID(requestID)
	if err != nil {
		return nil, err
	}

	// When marking under_review, claim edit authority for the caller's primary workbox
	// only if the record does not already have an edit authority assigned.
	var editAuth *string
	if status == "under_review" {
		existing, _ := s.repo.GetFrequencyRequestByID(requestID)
		if existing != nil && (existing.EditAuthorityWorkbox == nil || *existing.EditAuthorityWorkbox == "") {
			if name, ismErr := s.repo.GetUserPrimaryWorkboxName(reviewedBy); ismErr == nil {
				editAuth = name
			}
		}
	}

	// Update status
	err = s.repo.UpdateFrequencyRequestStatus(requestID, status, &reviewedBy, notes, "", "", editAuth)
	if err != nil {
		return nil, err
	}

	switch status {
	case "under_review":
		s.LogRequestEvent(requestID, &reviewedBy, "IN-PROCESS AT", "", notes)
	case "denied":
		s.LogRequestEvent(requestID, &reviewedBy, "REJECTED BY", "", notes)
	}

	// Get updated request
	return s.repo.GetFrequencyRequestByID(requestID)
}

func (s *FrequencyService) ApproveAndCreateAssignment(
	requestID uuid.UUID,
	approvedBy uuid.UUID,
	assignmentInput *models.CreateFrequencyAssignmentInput,
) (*models.FrequencyRequest, *models.FrequencyAssignment, error) {
	// Get the request
	request, err := s.repo.GetFrequencyRequestByID(requestID)
	if err != nil {
		return nil, nil, err
	}

	if request.Status == "approved" {
		return nil, nil, fmt.Errorf("request already approved")
	}

	// Create the frequency assignment
	assignment, err := s.CreateFrequencyAssignment(assignmentInput, approvedBy)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to create assignment: %w", err)
	}

	// Update request status
	err = s.repo.ApproveFrequencyRequest(requestID, approvedBy, assignment.ID)
	if err != nil {
		// Rollback assignment if request update fails
		s.repo.DeactivateFrequencyAssignment(assignment.ID)
		return nil, nil, fmt.Errorf("failed to approve request: %w", err)
	}

	s.LogRequestEvent(requestID, &approvedBy, "APPROVED BY", "", "")
	recordType := assignment.SFAFRecordType
	if recordType == "A" || recordType == "T" {
		s.LogAssignmentEvent(assignment.ID, &approvedBy, "ASSIGNED BY", "", "")
	} else {
		s.LogAssignmentEvent(assignment.ID, &approvedBy, "ORIGINATED BY", "", "")
	}

	// Get updated request
	updatedRequest, _ := s.repo.GetFrequencyRequestByID(requestID)
	return updatedRequest, assignment, nil
}

func (s *FrequencyService) ResubmitFrequencyRequest(requestID, userID uuid.UUID, input models.CreateFrequencyRequestInput) (*models.FrequencyRequest, error) {
	// Resolve edit authority and routing workbox, same logic as initial submission.
	var workbox *string
	if input.ISMOffice != "" {
		if _, parseErr := uuid.Parse(input.ISMOffice); parseErr != nil {
			workbox = &input.ISMOffice
		}
	}
	if workbox == nil {
		if name, err := s.repo.GetUserPrimaryWorkboxName(userID); err == nil {
			workbox = name
		}
	}
	req, err := s.repo.ResubmitFrequencyRequest(requestID, userID, input, workbox)
	if err == nil {
		s.LogRequestEvent(requestID, &userID, "RESUBMITTED BY", "", "")
	}
	return req, err
}

func (s *FrequencyService) GetUserRequestsWithDetails(userID uuid.UUID) ([]models.FrequencyRequestWithDetails, error) {
	requests, err := s.repo.GetUserFrequencyRequests(userID)
	if err != nil {
		return nil, err
	}

	result := make([]models.FrequencyRequestWithDetails, 0, len(requests))
	for _, request := range requests {
		unit, _ := s.repo.GetUnitByID(request.UnitID)
		requester, _ := s.userRepo.GetUserByID(request.RequestedBy)

		result = append(result, models.FrequencyRequestWithDetails{
			Request:     &request,
			Unit:        unit,
			RequestedBy: requester,
		})
	}

	return result, nil
}

func (s *FrequencyService) GetPendingRequestsWithDetails(callerID uuid.UUID, isAdmin bool) ([]models.FrequencyRequestWithDetails, error) {
	var callerWorkboxes []string
	if !isAdmin {
		callerWorkboxes, _ = s.repo.GetUserWorkboxNames(callerID)
	}
	requests, err := s.repo.GetPendingRequests(callerWorkboxes, isAdmin)
	if err != nil {
		return nil, err
	}

	requestIDs := make([]uuid.UUID, len(requests))
	for i, req := range requests {
		requestIDs[i] = req.ID
	}
	historyMap, _ := s.repo.BulkGetRequestStatusLog(requestIDs)

	result := make([]models.FrequencyRequestWithDetails, 0, len(requests))
	for _, request := range requests {
		unit, _ := s.repo.GetUnitByID(request.UnitID)
		requester, _ := s.userRepo.GetUserByID(request.RequestedBy)

		var install *models.Installation
		if unit != nil && unit.InstallationID != nil && s.installRepo != nil {
			install, _ = s.installRepo.GetByID(*unit.InstallationID)
		}

		comments, _ := s.repo.GetRequestComments(request.ID)
		history := historyMap[request.ID]
		if history == nil {
			history = []models.StatusLogEntry{}
		}
		coordinated, _ := s.repo.GetRequestCoordinations(request.ID)

		// Resolve linked assignment and edit authority.
		// Priority: request's own edit_authority_workbox (set on distribution)
		//           → linked assignment's edit_authority_workbox
		//           → requester's ISM unit (initial submission fallback)
		var linkedAssignment *models.FrequencyAssignment
		var editAuthority *string

		if request.EditAuthorityWorkbox != nil {
			editAuthority = request.EditAuthorityWorkbox
		}

		if request.AssignmentID != nil {
			if a, err := s.repo.GetFrequencyAssignmentByID(*request.AssignmentID); err == nil {
				linkedAssignment = a
				if editAuthority == nil && a.EditAuthorityWorkbox != nil {
					editAuthority = a.EditAuthorityWorkbox
				}
			}
		}
		var originWorkbox *string
		if name, err := s.repo.GetUserPrimaryWorkboxName(request.RequestedBy); err == nil && name != nil {
			originWorkbox = name
		}
		if editAuthority == nil {
			editAuthority = originWorkbox
		}

		result = append(result, models.FrequencyRequestWithDetails{
			Request:              &request,
			Unit:                 unit,
			Installation:         install,
			RequestedBy:          requester,
			Assignment:           linkedAssignment,
			Comments:             comments,
			History:              history,
			CoordinatedWith:      coordinated,
			EditAuthorityWorkbox: editAuthority,
			OriginWorkbox:        originWorkbox,
		})
	}

	return result, nil
}

// ============================================
// Conflict Detection (Basic Implementation)
// ============================================

func (s *FrequencyService) CheckFrequencyConflicts(
	frequencyMhz float64,
	unitID uuid.UUID,
	radiusKm float64,
) ([]models.FrequencyAssignment, error) {
	// Simple frequency proximity check
	// In a real system, this would include geographic distance calculations
	minFreq := frequencyMhz - 0.025 // 25 kHz spacing
	maxFreq := frequencyMhz + 0.025

	query := &models.FrequencySearchQuery{
		MinFrequency:  &minFreq,
		MaxFrequency:  &maxFreq,
		ExcludeUnitID: &unitID,
	}

	return s.repo.SearchAvailableFrequencies(query)
}

// ============================================
// Authorization Helpers
// ============================================

func (s *FrequencyService) CanUserManageUnit(userID, unitID uuid.UUID) (bool, error) {
	units, err := s.repo.GetUserUnits(userID)
	if err != nil {
		return false, err
	}

	for _, unit := range units {
		if unit.ID == unitID {
			return true, nil
		}
	}

	return false, nil
}

// GetSubmittedAssignments returns all P/S assignments from the given user's ISM unit,
// enriched with unit info. These populate the Submitted Proposals workbox sub-tab.
func (s *FrequencyService) GetSubmittedAssignments(userID uuid.UUID) ([]models.FrequencyAssignmentWithDetails, error) {
	assignments, err := s.repo.GetSubmittedAssignments(userID)
	if err != nil {
		return nil, err
	}
	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, a := range assignments {
		unit, _ := s.repo.GetUnitByID(a.UnitID)
		result = append(result, models.FrequencyAssignmentWithDetails{Assignment: &a, Unit: unit})
	}
	return result, nil
}

// GetInboundAssignments returns P/S assignments routed to any of the user's workboxes.
// These populate the Action Items workbox sub-tab alongside pending requests.
func (s *FrequencyService) GetInboundAssignments(userID uuid.UUID) ([]models.FrequencyAssignmentWithDetails, error) {
	workboxNames, _ := s.repo.GetUserWorkboxNames(userID)
	if len(workboxNames) == 0 {
		return nil, nil // user has no workbox assignments — return empty, not an error
	}
	assignments, err := s.repo.GetInboundAssignments(workboxNames)
	if err != nil {
		return nil, err
	}
	asnIDs := make([]uuid.UUID, len(assignments))
	for i, a := range assignments {
		asnIDs[i] = a.ID
	}
	historyMap, _ := s.repo.BulkGetAssignmentStatusLog(asnIDs)

	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, a := range assignments {
		unit, _ := s.repo.GetUnitByID(a.UnitID)
		detail := models.FrequencyAssignmentWithDetails{Assignment: &a, Unit: unit}
		if a.CreatedBy != nil {
			detail.CreatedBy, _ = s.userRepo.GetUserByID(*a.CreatedBy)
		}
		detail.CoordinatedWith, _ = s.repo.GetCoordinations(a.ID)
		detail.Comments, _ = s.repo.GetComments(a.ID)
		detail.History = historyMap[a.ID]
		if detail.History == nil {
			detail.History = []models.StatusLogEntry{}
		}
		result = append(result, detail)
	}
	return result, nil
}

// GetProposalAssignments returns P/S proposals visible to the given user role.
func (s *FrequencyService) GetProposalAssignments(userID uuid.UUID, role string) ([]models.FrequencyAssignmentWithDetails, error) {
	level := roleLevels[role]
	assignments, err := s.repo.GetProposalAssignments(userID, level)
	if err != nil {
		return nil, err
	}
	asnIDs := make([]uuid.UUID, len(assignments))
	for i, a := range assignments {
		asnIDs[i] = a.ID
	}
	historyMap, _ := s.repo.BulkGetAssignmentStatusLog(asnIDs)

	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, a := range assignments {
		unit, _ := s.repo.GetUnitByID(a.UnitID)
		detail := models.FrequencyAssignmentWithDetails{Assignment: &a, Unit: unit}
		if a.CreatedBy != nil {
			detail.CreatedBy, _ = s.userRepo.GetUserByID(*a.CreatedBy)
		}
		detail.CoordinatedWith, _ = s.repo.GetCoordinations(a.ID)
		detail.Comments, _ = s.repo.GetComments(a.ID)
		detail.History = historyMap[a.ID]
		if detail.History == nil {
			detail.History = []models.StatusLogEntry{}
		}
		result = append(result, detail)
	}
	return result, nil
}

// SetCoordinations replaces the lateral coordination workboxes for a proposal.
func (s *FrequencyService) SetCoordinations(assignmentID uuid.UUID, workboxes []string) error {
	return s.repo.SetCoordinations(assignmentID, workboxes)
}

// GetCoordinations returns the coordinated workboxes for a proposal.
func (s *FrequencyService) GetCoordinations(assignmentID uuid.UUID) ([]string, error) {
	return s.repo.GetCoordinations(assignmentID)
}

// AddComment adds a comment to the proposal's comment log.
func (s *FrequencyService) AddComment(assignmentID uuid.UUID, callerID uuid.UUID, workbox, body string) (*models.AssignmentComment, error) {
	c := &models.AssignmentComment{
		AssignmentID: assignmentID,
		CreatedBy:    &callerID,
		Workbox:      workbox,
		Body:         body,
	}
	if err := s.repo.AddComment(c); err != nil {
		return nil, err
	}
	if user, err := s.userRepo.GetUserByID(callerID); err == nil && user != nil {
		c.AuthorName = user.FullName
	}
	return c, nil
}

// GetComments returns the comment log for a proposal.
func (s *FrequencyService) GetComments(assignmentID uuid.UUID) ([]models.AssignmentComment, error) {
	return s.repo.GetComments(assignmentID)
}

// AddRequestComment adds a comment to a pending request's status log.
func (s *FrequencyService) AddRequestComment(requestID uuid.UUID, callerID uuid.UUID, workbox, body string) (*models.RequestComment, error) {
	c := &models.RequestComment{
		RequestID: requestID,
		CreatedBy: &callerID,
		Workbox:   workbox,
		Body:      body,
	}
	if err := s.repo.AddRequestComment(c); err != nil {
		return nil, err
	}
	if user, err := s.userRepo.GetUserByID(callerID); err == nil && user != nil {
		c.AuthorName = user.FullName
	}
	return c, nil
}

// GetRequestComments returns the status log for a pending request.
func (s *FrequencyService) GetRequestComments(requestID uuid.UUID) ([]models.RequestComment, error) {
	return s.repo.GetRequestComments(requestID)
}

// SetRequestCoordinations replaces the lateral coordination workboxes for a pending request.
func (s *FrequencyService) SetRequestCoordinations(requestID uuid.UUID, workboxes []string) error {
	return s.repo.SetRequestCoordinations(requestID, workboxes)
}

// GetRequestCoordinations returns the coordinated workboxes for a pending request.
func (s *FrequencyService) GetRequestCoordinations(requestID uuid.UUID) ([]string, error) {
	return s.repo.GetRequestCoordinations(requestID)
}

// GetAssignmentsInRange returns all active assignments in the given MHz band.
func (s *FrequencyService) GetAssignmentsInRange(minMhz, maxMhz float64) ([]models.FrequencyAssignment, error) {
	return s.repo.GetAssignmentsInRange(minMhz, maxMhz)
}

// GetReviewers returns active users who can review/elevate proposals (command and above).
func (s *FrequencyService) GetReviewers() ([]*models.User, error) {
	return s.userRepo.GetUsersByRoles([]string{"command", "combatant_command", "agency", "ntia", "admin"})
}

// ElevateAssignment promotes a P→A or S→T final assignment (agency+ only)
func (s *FrequencyService) ElevateAssignment(assignmentID, elevatedBy uuid.UUID, notes string) (*models.FrequencyAssignment, error) {
	if err := s.repo.ElevateAssignment(assignmentID, elevatedBy, notes); err != nil {
		return nil, fmt.Errorf("failed to elevate assignment: %w", err)
	}
	s.LogAssignmentEvent(assignmentID, &elevatedBy, "ASSIGNED BY", "", notes)
	a, err := s.repo.GetFrequencyAssignmentByID(assignmentID)
	if err != nil {
		return nil, err
	}
	// Per SXXI A.2.1: after ASSIGNED BY for a Temporary Assignment, the assigning JA
	// distributes/notifies the community → NOTIFIED BY is auto-applied.
	// Per SXXI A.2.3: after ASSIGNED BY for a non-reportable Permanent Assignment,
	// the record is registered with the register authority → REGISTERED WITH.
	switch a.SFAFRecordType {
	case "T":
		s.LogAssignmentEvent(assignmentID, &elevatedBy, "NOTIFIED BY", "", "")
	case "A":
		s.LogAssignmentEvent(assignmentID, &elevatedBy, "REGISTERED WITH", "", "")
	}
	return a, nil
}

// CleanupOrphanedAssignments removes frequency assignments that don't have corresponding SFAF records
func (s *FrequencyService) CleanupOrphanedAssignments() (int64, error) {
	return s.repo.CleanupOrphanedAssignments()
}

// RetractProposalAssignment deactivates a P/S proposal created by the caller.
// Returns the number of linked requests that were reset to pending.
func (s *FrequencyService) RetractProposalAssignment(assignmentID, createdBy uuid.UUID) (int64, error) {
	return s.repo.RetractProposalAssignment(assignmentID, createdBy)
}

// BulkRouteAssignments sets routed_to_workbox on the given P/S proposal IDs.
// Only the workbox that currently holds edit authority may distribute a record.
// Admins bypass the check.
func (s *FrequencyService) BulkRouteAssignments(ids []uuid.UUID, workbox *string, callerID uuid.UUID, isAdmin bool) (int64, error) {
	var callerWorkboxes []string
	if !isAdmin {
		callerWorkboxes, _ = s.repo.GetUserWorkboxNames(callerID)
	}
	return s.repo.BulkRouteAssignments(ids, workbox, callerWorkboxes)
}

// BulkRouteRequests sets routed_to_workbox on the given frequency request IDs.
func (s *FrequencyService) BulkRouteRequests(ids []uuid.UUID, workbox *string, callerID uuid.UUID, isAdmin bool) (int64, error) {
	var callerWorkboxes []string
	if !isAdmin {
		callerWorkboxes, _ = s.repo.GetUserWorkboxNames(callerID)
	}
	return s.repo.BulkRouteRequests(ids, workbox, callerWorkboxes)
}

// DeleteFrequencyRequest permanently removes a cancelled/denied request.
// GetRequestByID returns a frequency request by its ID.
func (s *FrequencyService) GetRequestByID(id uuid.UUID) (*models.FrequencyRequest, error) {
	return s.repo.GetFrequencyRequestByID(id)
}

// GetAssignmentByID returns a frequency assignment by its ID.
func (s *FrequencyService) GetAssignmentByID(id uuid.UUID) (*models.FrequencyAssignment, error) {
	return s.repo.GetFrequencyAssignmentByID(id)
}

// GetUserWorkboxNames returns all workbox names for a user. Used by the workbox handler.
func (s *FrequencyService) GetUserWorkboxNames(userID uuid.UUID) ([]string, error) {
	return s.repo.GetUserWorkboxNames(userID)
}

// GetUserISMUnit is kept for backward compatibility; prefer GetUserWorkboxNames for visibility.
func (s *FrequencyService) GetUserISMUnit(userID uuid.UUID) (*models.Unit, error) {
	return s.repo.GetUserISMUnit(userID)
}

// ReturnRequest sends a request back to the specified workbox (or all ISMs if empty).
func (s *FrequencyService) ReturnRequest(requestID uuid.UUID, forwardTo string) error {
	return s.repo.ReturnRequest(requestID, forwardTo)
}

func (s *FrequencyService) SaveRequestSFAFDraft(requestID uuid.UUID, draft []byte) error {
	return s.repo.SaveRequestSFAFDraft(requestID, draft)
}

func (s *FrequencyService) DeleteFrequencyRequest(requestID, requestedBy uuid.UUID, isAdmin bool) error {
	return s.repo.DeleteFrequencyRequest(requestID, requestedBy, isAdmin)
}

// RejectAndForwardRequest denies a request and routes it to the specified workbox.
// Per SXXI A.2, REJECTED BY is always followed by FORWARDED TO back to the previous JA.
func (s *FrequencyService) RejectAndForwardRequest(requestID, rejectedBy uuid.UUID, notes, forwardTo string) error {
	if err := s.repo.RejectAndForwardRequest(requestID, rejectedBy, notes, forwardTo); err != nil {
		return err
	}
	s.LogRequestEvent(requestID, &rejectedBy, "REJECTED BY", "", notes)
	s.LogRequestEvent(requestID, &rejectedBy, "FORWARDED TO", forwardTo, "")
	s.LogRequestEventAs(requestID, forwardTo, "RECEIVED BY", "", "")
	return nil
}

// RetractFrequencyRequest cancels a pending/under_review request, verifying
// the caller is the original requester.
func (s *FrequencyService) RetractFrequencyRequest(requestID, requestedBy uuid.UUID) (*models.FrequencyRequest, error) {
	if err := s.repo.RetractFrequencyRequest(requestID, requestedBy); err != nil {
		return nil, err
	}
	return s.repo.GetFrequencyRequestByID(requestID)
}

// GetFiveYearReviews returns permanent assignments due for 5-year review scoped to
// the requesting user's installation. Admins see all installations.
func (s *FrequencyService) GetFiveYearReviews(userID uuid.UUID, role string) ([]models.FrequencyAssignmentWithDetails, error) {
	user, err := s.userRepo.GetUserByID(userID)
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	// Admins see across all installations; ISMs are scoped to their installation.
	var installationID *uuid.UUID
	if roleLevels[role] < roleLevels["admin"] {
		installationID = user.InstallationID
	}

	assignments, err := s.repo.GetFiveYearReviews(installationID)
	if err != nil {
		return nil, err
	}

	result := make([]models.FrequencyAssignmentWithDetails, 0, len(assignments))
	for _, a := range assignments {
		unit, _ := s.repo.GetUnitByID(a.UnitID)
		result = append(result, models.FrequencyAssignmentWithDetails{Assignment: &a, Unit: unit})
	}
	return result, nil
}


// ── Control Numbers (702) ─────────────────────────────────────────────────────

func (s *FrequencyService) GetControlNumbers() ([]models.ControlNumber, error) {
	return s.repo.GetControlNumbers()
}

func (s *FrequencyService) CreateControlNumber(cn *models.ControlNumber) error {
	return s.repo.CreateControlNumber(cn)
}

func (s *FrequencyService) UpdateControlNumber(cn *models.ControlNumber) error {
	return s.repo.UpdateControlNumber(cn)
}

func (s *FrequencyService) DeleteControlNumber(id uuid.UUID) error {
	return s.repo.DeleteControlNumber(id)
}

// ── Workboxes ─────────────────────────────────────────────────────────────────

func (s *FrequencyService) GetAllWorkboxes() ([]models.Workbox, error) {
	return s.repo.GetAllWorkboxes()
}

func (s *FrequencyService) CreateWorkbox(w *models.Workbox) error {
	return s.repo.CreateWorkbox(w)
}

func (s *FrequencyService) UpdateWorkbox(w *models.Workbox) error {
	return s.repo.UpdateWorkbox(w)
}

func (s *FrequencyService) DeleteWorkbox(id uuid.UUID) error {
	return s.repo.DeleteWorkbox(id)
}

func (s *FrequencyService) GetWorkboxMembers(workboxID uuid.UUID) ([]models.UserWorkboxAssignment, error) {
	return s.repo.GetWorkboxMembers(workboxID)
}

func (s *FrequencyService) GetUserWorkboxAssignments(userID uuid.UUID) ([]models.UserWorkboxAssignment, error) {
	return s.repo.GetUserWorkboxAssignments(userID)
}

func (s *FrequencyService) AddWorkboxMember(userID, workboxID uuid.UUID, isPrimary bool) error {
	return s.repo.AddWorkboxMember(userID, workboxID, isPrimary)
}

func (s *FrequencyService) RemoveWorkboxMember(userID, workboxID uuid.UUID) error {
	return s.repo.RemoveWorkboxMember(userID, workboxID)
}

// SetPrimaryWorkbox switches which workbox the user is currently working from.
// The user must already be assigned to the target workbox.
func (s *FrequencyService) SetPrimaryWorkbox(userID, workboxID uuid.UUID) error {
	assignments, err := s.repo.GetUserWorkboxAssignments(userID)
	if err != nil {
		return err
	}
	for _, a := range assignments {
		if a.WorkboxID == workboxID {
			return s.repo.AddWorkboxMember(userID, workboxID, true)
		}
	}
	return fmt.Errorf("you are not assigned to that workbox")
}

// ── Status Log ────────────────────────────────────────────────────────────────

// LogAssignmentEvent records a workflow transition for an assignment/proposal.
// Failures are silent — the log is informational and must not block the workflow.
// actorWorkboxOverride, when non-empty, is used as the actor_workbox instead of
// deriving it from actorID — used for server-applied codes (e.g. RECEIVED BY).
func (s *FrequencyService) LogAssignmentEvent(assignmentID uuid.UUID, actorID *uuid.UUID, statusCode, targetWorkbox, notes string) {
	workbox := ""
	if actorID != nil {
		if wb, err := s.repo.GetUserPrimaryWorkboxName(*actorID); err == nil && wb != nil {
			workbox = *wb
		}
	}
	_ = s.repo.LogAssignmentStatus(assignmentID, statusCode, workbox, actorID, targetWorkbox, notes)
}

// LogAssignmentEventAs records a workflow event with an explicit actor workbox string
// instead of deriving it from a user ID. Used for server-applied codes such as RECEIVED BY
// where the actor is the recipient workbox, not the forwarding user.
func (s *FrequencyService) LogAssignmentEventAs(assignmentID uuid.UUID, actorWorkbox, statusCode, targetWorkbox, notes string) {
	_ = s.repo.LogAssignmentStatus(assignmentID, statusCode, actorWorkbox, nil, targetWorkbox, notes)
}

// LogRequestEvent records a workflow transition for a frequency request.
func (s *FrequencyService) LogRequestEvent(requestID uuid.UUID, actorID *uuid.UUID, statusCode, targetWorkbox, notes string) {
	workbox := ""
	if actorID != nil {
		if wb, err := s.repo.GetUserPrimaryWorkboxName(*actorID); err == nil && wb != nil {
			workbox = *wb
		}
	}
	_ = s.repo.LogRequestStatus(requestID, statusCode, workbox, actorID, targetWorkbox, notes)
}

// LogRequestEventAs records a workflow event with an explicit actor workbox string.
func (s *FrequencyService) LogRequestEventAs(requestID uuid.UUID, actorWorkbox, statusCode, targetWorkbox, notes string) {
	_ = s.repo.LogRequestStatus(requestID, statusCode, actorWorkbox, nil, targetWorkbox, notes)
}

func (s *FrequencyService) GetAssignmentHistory(assignmentID uuid.UUID) ([]models.StatusLogEntry, error) {
	return s.repo.GetAssignmentStatusLog(assignmentID)
}

func (s *FrequencyService) GetRequestHistory(requestID uuid.UUID) ([]models.StatusLogEntry, error) {
	return s.repo.GetRequestStatusLog(requestID)
}
