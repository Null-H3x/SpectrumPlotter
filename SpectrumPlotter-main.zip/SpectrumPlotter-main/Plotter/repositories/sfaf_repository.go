// sfaf_repository.go
package repositories

import (
	"database/sql"
	"fmt"
	"log"
	"regexp"
	"sfaf-plotter/models"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type SFAFRepository struct {
	db *sqlx.DB
}

func NewSFAFRepository(db *sqlx.DB) *SFAFRepository {
	return &SFAFRepository{db: db}
}

func (r *SFAFRepository) Create(sfaf *models.SFAF) error {
	sfaf.ID = uuid.New()
	now := time.Now()
	sfaf.CreatedAt = now
	sfaf.UpdatedAt = now

	// Build the complete INSERT query with all fields
	query := `
        INSERT INTO sfafs (
            id, marker_id, created_at, updated_at,
            field005, field006, field007, field010, field013, field014, field015, field016, field017, field018, field019, field020,
            field102, field103, field105, field106, field107, field108,
            field110, field111, field112, field113, field114, field115, field116, field117, field118,
            field130, field131, field140, field141, field142, field143, field144, field145, field146, field147, field151, field152,
            field200, field201, field202, field203, field204, field205, field206, field207, field208, field209,
            field300, field301, field302, field303, field304, field306,
            field315, field316, field317, field318, field319, field321,
            field340, field341, field342, field343, field344, field345, field346, field347, field348, field349,
            field354, field355, field356, field357, field358, field359, field360, field361, field362, field363, field364, field365, field373, field374,
            field400, field401, field403, field406, field407, field408,
            field415, field416, field417, field418, field419,
            field440, field442, field443,
            field453, field454, field455, field456, field457, field458, field459, field460, field461, field462, field463, field470, field471, field472, field473,
            field500, field501, field502, field503, field504, field506, field511, field512, field513, field520, field521, field530, field531,
            field701, field702, field704, field707, field710, field711, field716,
            field801, field803, field804, field805, field806,
            field901, field903, field904, field905, field906, field907, field910, field911, field924, field926, field927, field928,
            field952, field953, field956, field957, field958, field959, field963, field964, field965,
            field982, field983, field984, field985, field986, field987, field988, field989, field990, field991, field992, field993, field994, field995, field996, field997, field998, field999,
            sfaf_record_type
        ) VALUES (
            $1, $2, $3, $4,
            $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
            $17, $18, $19, $20, $21, $22,
            $23, $24, $25, $26, $27, $28, $29, $30, $31,
            $32, $33, $34, $35, $36, $37, $38, $39, $40, $41, $42, $43,
            $44, $45, $46, $47, $48, $49, $50, $51, $52, $53,
            $54, $55, $56, $57, $58, $59,
            $60, $61, $62, $63, $64, $65,
            $66, $67, $68, $69, $70, $71, $72, $73, $74, $75,
            $76, $77, $78, $79, $80, $81, $82, $83, $84, $85, $86, $87, $88, $89,
            $90, $91, $92, $93, $94, $95,
            $96, $97, $98, $99, $100,
            $101, $102, $103,
            $104, $105, $106, $107, $108, $109, $110, $111, $112, $113, $114, $115, $116, $117, $118,
            $119, $120, $121, $122, $123, $124, $125, $126, $127, $128, $129, $130, $131,
            $132, $133, $134, $135, $136, $137, $138,
            $139, $140, $141, $142, $143,
            $144, $145, $146, $147, $148, $149, $150, $151, $152, $153, $154, $155,
            $156, $157, $158, $159, $160, $161, $162, $163, $164,
            $165, $166, $167, $168, $169, $170, $171, $172, $173, $174, $175, $176, $177, $178, $179, $180, $181, $182,
            $183
        )`

	_, err := r.db.Exec(query,
		sfaf.ID, sfaf.MarkerID, sfaf.CreatedAt, sfaf.UpdatedAt,
		// 000 Series - Basic Information
		sfaf.Field005, sfaf.Field006, sfaf.Field007, sfaf.Field010, sfaf.Field013, sfaf.Field014, sfaf.Field015, sfaf.Field016, sfaf.Field017, sfaf.Field018, sfaf.Field019, sfaf.Field020,
		// 100 Series - Agency Information
		sfaf.Field102, sfaf.Field103, sfaf.Field105, sfaf.Field106, sfaf.Field107, sfaf.Field108,
		sfaf.Field110, sfaf.Field111, sfaf.Field112, sfaf.Field113, sfaf.Field114, sfaf.Field115, sfaf.Field116, sfaf.Field117, sfaf.Field118,
		// 100 Series Continued + Date Fields
		sfaf.Field130, sfaf.Field131, sfaf.Field140, sfaf.Field141, sfaf.Field142, sfaf.Field143, sfaf.Field144, sfaf.Field145, sfaf.Field146, sfaf.Field147, sfaf.Field151, sfaf.Field152,
		// 200 Series - System Information
		sfaf.Field200, sfaf.Field201, sfaf.Field202, sfaf.Field203, sfaf.Field204, sfaf.Field205, sfaf.Field206, sfaf.Field207, sfaf.Field208, sfaf.Field209,
		// 300 Series - Location Information
		sfaf.Field300, sfaf.Field301, sfaf.Field302, sfaf.Field303, sfaf.Field304, sfaf.Field306,
		// Technical Parameters (NUMERIC and INTEGER types)
		sfaf.Field315, sfaf.Field316, sfaf.Field317, sfaf.Field318, sfaf.Field319, sfaf.Field321,
		// Equipment Information
		sfaf.Field340, sfaf.Field341, sfaf.Field342, sfaf.Field343, sfaf.Field344, sfaf.Field345, sfaf.Field346, sfaf.Field347, sfaf.Field348, sfaf.Field349,
		// Advanced Technical Parameters
		sfaf.Field354, sfaf.Field355, sfaf.Field356, sfaf.Field357, sfaf.Field358, sfaf.Field359, sfaf.Field360, sfaf.Field361, sfaf.Field362, sfaf.Field363, sfaf.Field364, sfaf.Field365, sfaf.Field373, sfaf.Field374,
		// 400 Series - Radio/Frequency Parameters
		sfaf.Field400, sfaf.Field401, sfaf.Field403, sfaf.Field406, sfaf.Field407, sfaf.Field408,
		sfaf.Field415, sfaf.Field416, sfaf.Field417, sfaf.Field418, sfaf.Field419,
		// System Configuration
		sfaf.Field440, sfaf.Field442, sfaf.Field443,
		// Extended Equipment
		sfaf.Field453, sfaf.Field454, sfaf.Field455, sfaf.Field456, sfaf.Field457, sfaf.Field458, sfaf.Field459, sfaf.Field460, sfaf.Field461, sfaf.Field462, sfaf.Field463, sfaf.Field470, sfaf.Field471, sfaf.Field472, sfaf.Field473,
		// 500 Series - IRAC Notes and Equipment
		sfaf.Field500, sfaf.Field501, sfaf.Field502, sfaf.Field503, sfaf.Field504, sfaf.Field506, sfaf.Field511, sfaf.Field512, sfaf.Field513, sfaf.Field520, sfaf.Field521, sfaf.Field530, sfaf.Field531,
		// 700 Series - Coordination Information
		sfaf.Field701, sfaf.Field702, sfaf.Field704, sfaf.Field707, sfaf.Field710, sfaf.Field711, sfaf.Field716,
		// 800 Series - Administrative Information
		sfaf.Field801, sfaf.Field803, sfaf.Field804, sfaf.Field805, sfaf.Field806,
		// 900 Series - Comments and Processing
		sfaf.Field901, sfaf.Field903, sfaf.Field904, sfaf.Field905, sfaf.Field906, sfaf.Field907, sfaf.Field910, sfaf.Field911, sfaf.Field924, sfaf.Field926, sfaf.Field927, sfaf.Field928,
		// 950+ Series - Final Processing
		sfaf.Field952, sfaf.Field953, sfaf.Field956, sfaf.Field957, sfaf.Field958, sfaf.Field959, sfaf.Field963, sfaf.Field964, sfaf.Field965,
		// 980+ Series - System and Archive Information
		sfaf.Field982, sfaf.Field983, sfaf.Field984, sfaf.Field985, sfaf.Field986, sfaf.Field987, sfaf.Field988, sfaf.Field989, sfaf.Field990, sfaf.Field991, sfaf.Field992, sfaf.Field993, sfaf.Field994, sfaf.Field995, sfaf.Field996, sfaf.Field997, sfaf.Field998, sfaf.Field999,
		sfaf.SFAFRecordType,
	)

	return err
}

func (r *SFAFRepository) GetByID(id string) (*models.SFAF, error) {
	sfafID, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid UUID: %v", err)
	}

	var sfaf models.SFAF

	// ✅ CORRECT: Use individual field columns from sfafs table (Source: table_info.txt)
	query := `
        SELECT id, marker_id, created_at, updated_at,
               COALESCE(field005, ''), COALESCE(field006, ''), COALESCE(field007, ''), COALESCE(field010, ''), COALESCE(field013, ''), COALESCE(field014, ''), COALESCE(field015, ''), COALESCE(field016, ''), COALESCE(field017, ''), COALESCE(field018, ''), COALESCE(field019, ''), COALESCE(field020, ''),
               COALESCE(field102, ''), COALESCE(field103, ''), COALESCE(field105, ''), COALESCE(field106, ''), COALESCE(field107, ''), COALESCE(field108, ''), COALESCE(field110, ''), COALESCE(field111, ''), COALESCE(field112, ''), COALESCE(field113, ''), COALESCE(field114, ''), COALESCE(field115, ''), COALESCE(field116, ''), COALESCE(field117, ''), COALESCE(field118, ''),
               COALESCE(field130, ''), COALESCE(field131, ''), field140, field141, field142, field143, COALESCE(field144, ''), COALESCE(field145, ''), COALESCE(field146, ''), COALESCE(field147, ''), COALESCE(field151, ''), COALESCE(field152, ''),
               COALESCE(field200, ''), COALESCE(field201, ''), COALESCE(field202, ''), COALESCE(field203, ''), COALESCE(field204, ''), COALESCE(field205, ''), COALESCE(field206, ''), COALESCE(field207, ''), COALESCE(field208, ''), COALESCE(field209, ''),
               COALESCE(field300, ''), COALESCE(field301, ''), COALESCE(field302, ''), COALESCE(field303, ''), COALESCE(field304, ''), COALESCE(field306, ''),
               field315, field316, field317, COALESCE(field318, ''), field319, field321,
               COALESCE(field340, ''), COALESCE(field341, ''), COALESCE(field342, ''), COALESCE(field343, ''), COALESCE(field344, ''), COALESCE(field345, ''), COALESCE(field346, ''), COALESCE(field347, ''), COALESCE(field348, ''), COALESCE(field349, ''),
               COALESCE(field354, ''), COALESCE(field355, ''), field356, field357, field358, field359, field360, field361, COALESCE(field362, ''), COALESCE(field363, ''), field364, field365, COALESCE(field373, ''), COALESCE(field374, ''),
               COALESCE(field400, ''), COALESCE(field401, ''), COALESCE(field403, ''), COALESCE(field406, ''), COALESCE(field407, ''), COALESCE(field408, ''), field415, field416, field417, COALESCE(field418, ''), field419,
               COALESCE(field440, ''), COALESCE(field442, ''), COALESCE(field443, ''),
               COALESCE(field453, ''), COALESCE(field454, ''), COALESCE(field455, ''), field456, field457, field458, field459, field460, field461, COALESCE(field462, ''), COALESCE(field463, ''), field470, field471, field472, COALESCE(field473, ''),
               COALESCE(field500, ''), COALESCE(field501, ''), COALESCE(field502, ''), COALESCE(field503, ''), COALESCE(field504, ''), COALESCE(field506, ''), COALESCE(field511, ''), COALESCE(field512, ''), COALESCE(field513, ''), COALESCE(field520, ''), COALESCE(field521, ''), COALESCE(field530, ''), COALESCE(field531, ''),
               COALESCE(field701, ''), COALESCE(field702, ''), COALESCE(field704, ''), COALESCE(field707, ''), COALESCE(field710, ''), COALESCE(field711, ''), COALESCE(field716, ''),
               COALESCE(field801, ''), COALESCE(field803, ''), COALESCE(field804, ''), field805, COALESCE(field806, ''),
               COALESCE(field901, ''), COALESCE(field903, ''), field904, COALESCE(field905, ''), COALESCE(field906, ''), COALESCE(field907, ''), COALESCE(field910, ''), field911, COALESCE(field924, ''), field926, field927, field928,
               COALESCE(field952, ''), COALESCE(field953, ''), COALESCE(field956, ''), field957, COALESCE(field958, ''), COALESCE(field959, ''), COALESCE(field963, ''), field964, field965,
               COALESCE(field982, ''), COALESCE(field983, ''), COALESCE(field984, ''), COALESCE(field985, ''), COALESCE(field986, ''), COALESCE(field987, ''), COALESCE(field988, ''), COALESCE(field989, ''), COALESCE(field990, ''), COALESCE(field991, ''), COALESCE(field992, ''), COALESCE(field993, ''), COALESCE(field994, ''), COALESCE(field995, ''), COALESCE(field996, ''), COALESCE(field997, ''), COALESCE(field998, ''), COALESCE(field999, ''),
               sfaf_record_type
        FROM sfafs 
        WHERE id = $1`

	// ✅ CORRECT: Scan individual fields directly into struct fields (Source: models.txt)
	err = r.db.QueryRow(query, sfafID).Scan(
		&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
		&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
		&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
		&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
		&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
		&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
		&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
		&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
		&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
		&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
		&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
		&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
		&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
		&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
		&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
		&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
		&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
		&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
		&sfaf.SFAFRecordType)

	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get SFAF: %w", err)
	}

	return &sfaf, nil
}

func (r *SFAFRepository) GetByMarkerID(markerID string) (*models.SFAF, error) {
	markerUUID, err := uuid.Parse(markerID)
	if err != nil {
		return nil, fmt.Errorf("invalid marker ID: %v", err)
	}

	var sfaf models.SFAF

	// ✅ CORRECT: Use individual field columns from sfafs table (Source: table_info.txt)
	query := `
        SELECT id, marker_id, created_at, updated_at,
               COALESCE(field005, ''), COALESCE(field006, ''), COALESCE(field007, ''), COALESCE(field010, ''), COALESCE(field013, ''), COALESCE(field014, ''), COALESCE(field015, ''), COALESCE(field016, ''), COALESCE(field017, ''), COALESCE(field018, ''), COALESCE(field019, ''), COALESCE(field020, ''),
               COALESCE(field102, ''), COALESCE(field103, ''), COALESCE(field105, ''), COALESCE(field106, ''), COALESCE(field107, ''), COALESCE(field108, ''), COALESCE(field110, ''), COALESCE(field111, ''), COALESCE(field112, ''), COALESCE(field113, ''), COALESCE(field114, ''), COALESCE(field115, ''), COALESCE(field116, ''), COALESCE(field117, ''), COALESCE(field118, ''),
               COALESCE(field130, ''), COALESCE(field131, ''), field140, field141, field142, field143, COALESCE(field144, ''), COALESCE(field145, ''), COALESCE(field146, ''), COALESCE(field147, ''), COALESCE(field151, ''), COALESCE(field152, ''),
               COALESCE(field200, ''), COALESCE(field201, ''), COALESCE(field202, ''), COALESCE(field203, ''), COALESCE(field204, ''), COALESCE(field205, ''), COALESCE(field206, ''), COALESCE(field207, ''), COALESCE(field208, ''), COALESCE(field209, ''),
               COALESCE(field300, ''), COALESCE(field301, ''), COALESCE(field302, ''), COALESCE(field303, ''), COALESCE(field304, ''), COALESCE(field306, ''),
               field315, field316, field317, COALESCE(field318, ''), field319, field321,
               COALESCE(field340, ''), COALESCE(field341, ''), COALESCE(field342, ''), COALESCE(field343, ''), COALESCE(field344, ''), COALESCE(field345, ''), COALESCE(field346, ''), COALESCE(field347, ''), COALESCE(field348, ''), COALESCE(field349, ''),
               COALESCE(field354, ''), COALESCE(field355, ''), field356, field357, field358, field359, field360, field361, COALESCE(field362, ''), COALESCE(field363, ''), field364, field365, COALESCE(field373, ''), COALESCE(field374, ''),
               COALESCE(field400, ''), COALESCE(field401, ''), COALESCE(field403, ''), COALESCE(field406, ''), COALESCE(field407, ''), COALESCE(field408, ''), field415, field416, field417, COALESCE(field418, ''), field419,
               COALESCE(field440, ''), COALESCE(field442, ''), COALESCE(field443, ''),
               COALESCE(field453, ''), COALESCE(field454, ''), COALESCE(field455, ''), field456, field457, field458, field459, field460, field461, COALESCE(field462, ''), COALESCE(field463, ''), field470, field471, field472, COALESCE(field473, ''),
               COALESCE(field500, ''), COALESCE(field501, ''), COALESCE(field502, ''), COALESCE(field503, ''), COALESCE(field504, ''), COALESCE(field506, ''), COALESCE(field511, ''), COALESCE(field512, ''), COALESCE(field513, ''), COALESCE(field520, ''), COALESCE(field521, ''), COALESCE(field530, ''), COALESCE(field531, ''),
               COALESCE(field701, ''), COALESCE(field702, ''), COALESCE(field704, ''), COALESCE(field707, ''), COALESCE(field710, ''), COALESCE(field711, ''), COALESCE(field716, ''),
               COALESCE(field801, ''), COALESCE(field803, ''), COALESCE(field804, ''), field805, COALESCE(field806, ''),
               COALESCE(field901, ''), COALESCE(field903, ''), field904, COALESCE(field905, ''), COALESCE(field906, ''), COALESCE(field907, ''), COALESCE(field910, ''), field911, COALESCE(field924, ''), field926, field927, field928,
               COALESCE(field952, ''), COALESCE(field953, ''), COALESCE(field956, ''), field957, COALESCE(field958, ''), COALESCE(field959, ''), COALESCE(field963, ''), field964, field965,
               COALESCE(field982, ''), COALESCE(field983, ''), COALESCE(field984, ''), COALESCE(field985, ''), COALESCE(field986, ''), COALESCE(field987, ''), COALESCE(field988, ''), COALESCE(field989, ''), COALESCE(field990, ''), COALESCE(field991, ''), COALESCE(field992, ''), COALESCE(field993, ''), COALESCE(field994, ''), COALESCE(field995, ''), COALESCE(field996, ''), COALESCE(field997, ''), COALESCE(field998, ''), COALESCE(field999, ''),
               sfaf_record_type
        FROM sfafs 
        WHERE marker_id = $1`

	// ✅ CORRECT: Scan individual fields directly into struct fields (Source: models.txt)
	err = r.db.QueryRow(query, markerUUID).Scan(
		&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
		&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
		&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
		&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
		&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
		&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
		&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
		&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
		&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
		&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
		&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
		&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
		&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
		&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
		&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
		&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
		&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
		&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
		&sfaf.SFAFRecordType)

	if err == sql.ErrNoRows {
		return nil, nil // No SFAF record found for this marker
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get SFAF by marker ID: %w", err)
	}

	return &sfaf, nil
}

func (r *SFAFRepository) GetBySerial(serial string) (*models.SFAF, error) {
	var sfaf models.SFAF

	query := `
        SELECT id, marker_id, created_at, updated_at,
               COALESCE(field005, ''), COALESCE(field006, ''), COALESCE(field007, ''), COALESCE(field010, ''), COALESCE(field013, ''), COALESCE(field014, ''), COALESCE(field015, ''), COALESCE(field016, ''), COALESCE(field017, ''), COALESCE(field018, ''), COALESCE(field019, ''), COALESCE(field020, ''),
               COALESCE(field102, ''), COALESCE(field103, ''), COALESCE(field105, ''), COALESCE(field106, ''), COALESCE(field107, ''), COALESCE(field108, ''), COALESCE(field110, ''), COALESCE(field111, ''), COALESCE(field112, ''), COALESCE(field113, ''), COALESCE(field114, ''), COALESCE(field115, ''), COALESCE(field116, ''), COALESCE(field117, ''), COALESCE(field118, ''),
               COALESCE(field130, ''), COALESCE(field131, ''), field140, field141, field142, field143, COALESCE(field144, ''), COALESCE(field145, ''), COALESCE(field146, ''), COALESCE(field147, ''), COALESCE(field151, ''), COALESCE(field152, ''),
               COALESCE(field200, ''), COALESCE(field201, ''), COALESCE(field202, ''), COALESCE(field203, ''), COALESCE(field204, ''), COALESCE(field205, ''), COALESCE(field206, ''), COALESCE(field207, ''), COALESCE(field208, ''), COALESCE(field209, ''),
               COALESCE(field300, ''), COALESCE(field301, ''), COALESCE(field302, ''), COALESCE(field303, ''), COALESCE(field304, ''), COALESCE(field306, ''),
               field315, field316, field317, COALESCE(field318, ''), field319, field321,
               COALESCE(field340, ''), COALESCE(field341, ''), COALESCE(field342, ''), COALESCE(field343, ''), COALESCE(field344, ''), COALESCE(field345, ''), COALESCE(field346, ''), COALESCE(field347, ''), COALESCE(field348, ''), COALESCE(field349, ''),
               COALESCE(field354, ''), COALESCE(field355, ''), field356, field357, field358, field359, field360, field361, COALESCE(field362, ''), COALESCE(field363, ''), field364, field365, COALESCE(field373, ''), COALESCE(field374, ''),
               COALESCE(field400, ''), COALESCE(field401, ''), COALESCE(field403, ''), COALESCE(field406, ''), COALESCE(field407, ''), COALESCE(field408, ''), field415, field416, field417, COALESCE(field418, ''), field419,
               COALESCE(field440, ''), COALESCE(field442, ''), COALESCE(field443, ''),
               COALESCE(field453, ''), COALESCE(field454, ''), COALESCE(field455, ''), field456, field457, field458, field459, field460, field461, COALESCE(field462, ''), COALESCE(field463, ''), field470, field471, field472, COALESCE(field473, ''),
               COALESCE(field500, ''), COALESCE(field501, ''), COALESCE(field502, ''), COALESCE(field503, ''), COALESCE(field504, ''), COALESCE(field506, ''), COALESCE(field511, ''), COALESCE(field512, ''), COALESCE(field513, ''), COALESCE(field520, ''), COALESCE(field521, ''), COALESCE(field530, ''), COALESCE(field531, ''),
               COALESCE(field701, ''), COALESCE(field702, ''), COALESCE(field704, ''), COALESCE(field707, ''), COALESCE(field710, ''), COALESCE(field711, ''), COALESCE(field716, ''),
               COALESCE(field801, ''), COALESCE(field803, ''), COALESCE(field804, ''), field805, COALESCE(field806, ''),
               COALESCE(field901, ''), COALESCE(field903, ''), field904, COALESCE(field905, ''), COALESCE(field906, ''), COALESCE(field907, ''), COALESCE(field910, ''), field911, COALESCE(field924, ''), field926, field927, field928,
               COALESCE(field952, ''), COALESCE(field953, ''), COALESCE(field956, ''), field957, COALESCE(field958, ''), COALESCE(field959, ''), COALESCE(field963, ''), field964, field965,
               COALESCE(field982, ''), COALESCE(field983, ''), COALESCE(field984, ''), COALESCE(field985, ''), COALESCE(field986, ''), COALESCE(field987, ''), COALESCE(field988, ''), COALESCE(field989, ''), COALESCE(field990, ''), COALESCE(field991, ''), COALESCE(field992, ''), COALESCE(field993, ''), COALESCE(field994, ''), COALESCE(field995, ''), COALESCE(field996, ''), COALESCE(field997, ''), COALESCE(field998, ''), COALESCE(field999, ''),
               sfaf_record_type
        FROM sfafs
        WHERE field102 = $1
        LIMIT 1`

	err := r.db.QueryRow(query, serial).Scan(
		&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
		&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
		&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
		&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
		&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
		&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
		&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
		&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
		&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
		&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
		&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
		&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
		&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
		&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
		&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
		&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
		&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
		&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
		&sfaf.SFAFRecordType)

	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get SFAF by serial: %w", err)
	}

	return &sfaf, nil
}

func (r *SFAFRepository) LinkMarker(sfafID uuid.UUID, markerID uuid.UUID) error {
	_, err := r.db.Exec(`UPDATE sfafs SET marker_id = $1 WHERE id = $2`, markerID, sfafID)
	return err
}

func (r *SFAFRepository) Update(sfaf *models.SFAF) error {
	// Update timestamp
	now := time.Now()
	sfaf.UpdatedAt = now

	// ✅ CORRECT: Use individual field columns from sfafs table (Source: table_info.txt)
	query := `
        UPDATE sfafs 
        SET updated_at = $1,
            field005 = $2, field006 = $3, field007 = $4, field010 = $5, field013 = $6, field014 = $7, field015 = $8, field016 = $9, field017 = $10, field018 = $11, field019 = $12, field020 = $13,
            field102 = $14, field103 = $15, field105 = $16, field106 = $17, field107 = $18, field108 = $19, field110 = $20, field111 = $21, field112 = $22, field113 = $23, field114 = $24, field115 = $25, field116 = $26, field117 = $27, field118 = $28,
            field130 = $29, field131 = $30, field140 = $31, field141 = $32, field142 = $33, field143 = $34, field144 = $35, field145 = $36, field146 = $37, field147 = $38, field151 = $39, field152 = $40,
            field200 = $41, field201 = $42, field202 = $43, field203 = $44, field204 = $45, field205 = $46, field206 = $47, field207 = $48, field208 = $49, field209 = $50,
            field300 = $51, field301 = $52, field302 = $53, field303 = $54, field304 = $55, field306 = $56,
            field315 = $57, field316 = $58, field317 = $59, field318 = $60, field319 = $61, field321 = $62,
            field340 = $63, field341 = $64, field342 = $65, field343 = $66, field344 = $67, field345 = $68, field346 = $69, field347 = $70, field348 = $71, field349 = $72,
            field354 = $73, field355 = $74, field356 = $75, field357 = $76, field358 = $77, field359 = $78, field360 = $79, field361 = $80, field362 = $81, field363 = $82, field364 = $83, field365 = $84, field373 = $85, field374 = $86,
            field400 = $87, field401 = $88, field403 = $89, field406 = $90, field407 = $91, field408 = $92, field415 = $93, field416 = $94, field417 = $95, field418 = $96, field419 = $97,
            field440 = $98, field442 = $99, field443 = $100,
            field453 = $101, field454 = $102, field455 = $103, field456 = $104, field457 = $105, field458 = $106, field459 = $107, field460 = $108, field461 = $109, field462 = $110, field463 = $111, field470 = $112, field471 = $113, field472 = $114, field473 = $115,
            field500 = $116, field501 = $117, field502 = $118, field503 = $119, field504 = $120, field506 = $121, field511 = $122, field512 = $123, field513 = $124, field520 = $125, field521 = $126, field530 = $127, field531 = $128,
            field701 = $129, field702 = $130, field704 = $131, field707 = $132, field710 = $133, field711 = $134, field716 = $135,
            field801 = $136, field803 = $137, field804 = $138, field805 = $139, field806 = $140,
            field901 = $141, field903 = $142, field904 = $143, field905 = $144, field906 = $145, field907 = $146, field910 = $147, field911 = $148, field924 = $149, field926 = $150, field927 = $151, field928 = $152,
            field952 = $153, field953 = $154, field956 = $155, field957 = $156, field958 = $157, field959 = $158, field963 = $159, field964 = $160, field965 = $161,
            field982 = $162, field983 = $163, field984 = $164, field985 = $165, field986 = $166, field987 = $167, field988 = $168, field989 = $169, field990 = $170, field991 = $171, field992 = $172, field993 = $173, field994 = $174, field995 = $175, field996 = $176, field997 = $177, field998 = $178, field999 = $179
        WHERE id = $180`

	// ✅ CORRECT: Use individual field values directly from struct fields (Source: models.txt)
	result, err := r.db.Exec(query,
		now, // $1 - updated_at
		sfaf.Field005, sfaf.Field006, sfaf.Field007, sfaf.Field010, sfaf.Field013, sfaf.Field014, sfaf.Field015, sfaf.Field016, sfaf.Field017, sfaf.Field018, sfaf.Field019, sfaf.Field020,
		sfaf.Field102, sfaf.Field103, sfaf.Field105, sfaf.Field106, sfaf.Field107, sfaf.Field108, sfaf.Field110, sfaf.Field111, sfaf.Field112, sfaf.Field113, sfaf.Field114, sfaf.Field115, sfaf.Field116, sfaf.Field117, sfaf.Field118,
		sfaf.Field130, sfaf.Field131, sfaf.Field140, sfaf.Field141, sfaf.Field142, sfaf.Field143, sfaf.Field144, sfaf.Field145, sfaf.Field146, sfaf.Field147, sfaf.Field151, sfaf.Field152,
		sfaf.Field200, sfaf.Field201, sfaf.Field202, sfaf.Field203, sfaf.Field204, sfaf.Field205, sfaf.Field206, sfaf.Field207, sfaf.Field208, sfaf.Field209,
		sfaf.Field300, sfaf.Field301, sfaf.Field302, sfaf.Field303, sfaf.Field304, sfaf.Field306,
		sfaf.Field315, sfaf.Field316, sfaf.Field317, sfaf.Field318, sfaf.Field319, sfaf.Field321,
		sfaf.Field340, sfaf.Field341, sfaf.Field342, sfaf.Field343, sfaf.Field344, sfaf.Field345, sfaf.Field346, sfaf.Field347, sfaf.Field348, sfaf.Field349,
		sfaf.Field354, sfaf.Field355, sfaf.Field356, sfaf.Field357, sfaf.Field358, sfaf.Field359, sfaf.Field360, sfaf.Field361, sfaf.Field362, sfaf.Field363, sfaf.Field364, sfaf.Field365, sfaf.Field373, sfaf.Field374,
		sfaf.Field400, sfaf.Field401, sfaf.Field403, sfaf.Field406, sfaf.Field407, sfaf.Field408, sfaf.Field415, sfaf.Field416, sfaf.Field417, sfaf.Field418, sfaf.Field419,
		sfaf.Field440, sfaf.Field442, sfaf.Field443,
		sfaf.Field453, sfaf.Field454, sfaf.Field455, sfaf.Field456, sfaf.Field457, sfaf.Field458, sfaf.Field459, sfaf.Field460, sfaf.Field461, sfaf.Field462, sfaf.Field463, sfaf.Field470, sfaf.Field471, sfaf.Field472, sfaf.Field473,
		sfaf.Field500, sfaf.Field501, sfaf.Field502, sfaf.Field503, sfaf.Field504, sfaf.Field506, sfaf.Field511, sfaf.Field512, sfaf.Field513, sfaf.Field520, sfaf.Field521, sfaf.Field530, sfaf.Field531,
		sfaf.Field701, sfaf.Field702, sfaf.Field704, sfaf.Field707, sfaf.Field710, sfaf.Field711, sfaf.Field716,
		sfaf.Field801, sfaf.Field803, sfaf.Field804, sfaf.Field805, sfaf.Field806,
		sfaf.Field901, sfaf.Field903, sfaf.Field904, sfaf.Field905, sfaf.Field906, sfaf.Field907, sfaf.Field910, sfaf.Field911, sfaf.Field924, sfaf.Field926, sfaf.Field927, sfaf.Field928,
		sfaf.Field952, sfaf.Field953, sfaf.Field956, sfaf.Field957, sfaf.Field958, sfaf.Field959, sfaf.Field963, sfaf.Field964, sfaf.Field965,
		sfaf.Field982, sfaf.Field983, sfaf.Field984, sfaf.Field985, sfaf.Field986, sfaf.Field987, sfaf.Field988, sfaf.Field989, sfaf.Field990, sfaf.Field991, sfaf.Field992, sfaf.Field993, sfaf.Field994, sfaf.Field995, sfaf.Field996, sfaf.Field997, sfaf.Field998, sfaf.Field999,
		sfaf.ID) // $180 - WHERE clause

	if err != nil {
		return fmt.Errorf("failed to update SFAF: %w", err)
	}

	// Check if any rows were affected
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to get rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("SFAF with ID %s not found", sfaf.ID)
	}

	return nil
}

func (r *SFAFRepository) Delete(id string) error {
	log.Printf("🗑️ Delete called for SFAF ID: %s", id)

	sfafID, err := uuid.Parse(id)
	if err != nil {
		log.Printf("❌ Failed to parse UUID: %v", err)
		return err
	}
	log.Printf("✓ Parsed UUID: %s", sfafID)

	// First, get the SFAF record to find its serial number and marker_id
	var serial string
	var markerID sql.NullString
	getSerialQuery := `
		SELECT field102, marker_id
		FROM sfafs
		WHERE id = $1
	`
	log.Printf("🔍 Querying for SFAF serial and marker with ID: %s", sfafID)
	err = r.db.QueryRow(getSerialQuery, sfafID).Scan(&serial, &markerID)
	if err != nil {
		// If record doesn't exist, that's okay - nothing to delete
		if err.Error() == "sql: no rows in result set" {
			log.Printf("⚠️ SFAF record not found (already deleted?): %s", sfafID)
			return nil
		}
		log.Printf("❌ Error getting SFAF serial: %v", err)
		return fmt.Errorf("failed to get SFAF serial: %w", err)
	}
	log.Printf("✓ Found SFAF with serial: %s, marker_id: %v", serial, markerID)

	// Delete related frequency assignments with this serial
	deleteFreqAssignmentsQuery := `DELETE FROM frequency_assignments WHERE serial = $1`
	log.Printf("🗑️ Deleting frequency assignments for serial: %s", serial)
	result, err := r.db.Exec(deleteFreqAssignmentsQuery, serial)
	if err != nil {
		log.Printf("❌ Error deleting frequency assignments: %v", err)
		return fmt.Errorf("failed to delete frequency assignments: %w", err)
	}
	rowsAffected, _ := result.RowsAffected()
	log.Printf("✓ Deleted %d frequency assignments", rowsAffected)

	// Delete the SFAF record first (must be deleted before marker due to foreign key)
	query := `DELETE FROM sfafs WHERE id = $1`
	log.Printf("🗑️ Deleting SFAF record: %s", sfafID)
	result, err = r.db.Exec(query, sfafID)
	if err != nil {
		log.Printf("❌ Error deleting SFAF record: %v", err)
		return err
	}
	rowsAffected, _ = result.RowsAffected()
	log.Printf("✓ Successfully deleted SFAF record (rows affected: %d)", rowsAffected)

	// Delete associated marker if it exists
	if markerID.Valid {
		deleteMarkerQuery := `DELETE FROM markers WHERE id = $1`
		log.Printf("🗑️ Deleting associated marker: %s", markerID.String)
		result, err = r.db.Exec(deleteMarkerQuery, markerID.String)
		if err != nil {
			log.Printf("❌ Error deleting marker: %v", err)
			return fmt.Errorf("failed to delete marker: %w", err)
		}
		rowsAffected, _ = result.RowsAffected()
		log.Printf("✓ Successfully deleted marker (rows affected: %d)", rowsAffected)
	} else {
		log.Printf("ℹ️ No marker associated with this SFAF (Pool Assignment?)")
	}

	return nil
}

// DeleteAll deletes all SFAF records and their associated markers
func (r *SFAFRepository) DeleteAll() (int, error) {
	log.Printf("🗑️ Delete All SFAFs called")

	// Count total records before deletion
	var count int
	countQuery := `SELECT COUNT(*) FROM sfafs`
	err := r.db.QueryRow(countQuery).Scan(&count)
	if err != nil {
		log.Printf("❌ Failed to count SFAFs: %v", err)
		return 0, fmt.Errorf("failed to count SFAFs: %w", err)
	}
	log.Printf("📊 Found %d SFAF records to delete", count)

	// Delete all SFAFs (cascading deletes will handle field occurrences)
	deleteQuery := `DELETE FROM sfafs`
	log.Printf("🗑️ Deleting all SFAF records...")
	result, err := r.db.Exec(deleteQuery)
	if err != nil {
		log.Printf("❌ Error deleting all SFAF records: %v", err)
		return 0, fmt.Errorf("failed to delete all SFAFs: %w", err)
	}
	rowsAffected, _ := result.RowsAffected()
	log.Printf("✓ Successfully deleted %d SFAF records", rowsAffected)

	// Delete all markers (SFAFs are deleted first, so no FK constraint issues)
	deleteMarkersQuery := `DELETE FROM markers`
	log.Printf("🗑️ Deleting all marker records...")
	result, err = r.db.Exec(deleteMarkersQuery)
	if err != nil {
		log.Printf("❌ Error deleting all markers: %v", err)
		return int(rowsAffected), fmt.Errorf("deleted SFAFs but failed to delete markers: %w", err)
	}
	markersAffected, _ := result.RowsAffected()
	log.Printf("✓ Successfully deleted %d markers", markersAffected)

	log.Printf("✅ Delete All completed: %d SFAFs and %d markers deleted", rowsAffected, markersAffected)
	return count, nil
}

func (r *SFAFRepository) SaveSFAF(sfaf *models.SFAF) error {
	// Check if exists, then update or create
	existing, err := r.GetByID(sfaf.ID.String())
	if err != nil {
		return err
	}

	if existing != nil {
		return r.Update(sfaf)
	}

	return r.Create(sfaf)
}

func (r *SFAFRepository) GetPaginated(offset, limit int) ([]*models.SFAF, error) {
	// ✅ CORRECT: Use individual field columns from sfafs table with COALESCE to handle NULLs
	query := `
        SELECT id, marker_id, created_at, updated_at,
               COALESCE(field005, ''), COALESCE(field006, ''), COALESCE(field007, ''), COALESCE(field010, ''), COALESCE(field013, ''), COALESCE(field014, ''), COALESCE(field015, ''), COALESCE(field016, ''), COALESCE(field017, ''), COALESCE(field018, ''), COALESCE(field019, ''), COALESCE(field020, ''),
               COALESCE(field102, ''), COALESCE(field103, ''), COALESCE(field105, ''), COALESCE(field106, ''), COALESCE(field107, ''), COALESCE(field108, ''), COALESCE(field110, ''), COALESCE(field111, ''), COALESCE(field112, ''), COALESCE(field113, ''), COALESCE(field114, ''), COALESCE(field115, ''), COALESCE(field116, ''), COALESCE(field117, ''), COALESCE(field118, ''),
               COALESCE(field130, ''), COALESCE(field131, ''), field140, field141, field142, field143, COALESCE(field144, ''), COALESCE(field145, ''), COALESCE(field146, ''), COALESCE(field147, ''), COALESCE(field151, ''), COALESCE(field152, ''),
               COALESCE(field200, ''), COALESCE(field201, ''), COALESCE(field202, ''), COALESCE(field203, ''), COALESCE(field204, ''), COALESCE(field205, ''), COALESCE(field206, ''), COALESCE(field207, ''), COALESCE(field208, ''), COALESCE(field209, ''),
               COALESCE(field300, ''), COALESCE(field301, ''), COALESCE(field302, ''), COALESCE(field303, ''), COALESCE(field304, ''), COALESCE(field306, ''),
               field315, field316, field317, COALESCE(field318, ''), field319, field321,
               COALESCE(field340, ''), COALESCE(field341, ''), COALESCE(field342, ''), COALESCE(field343, ''), COALESCE(field344, ''), COALESCE(field345, ''), COALESCE(field346, ''), COALESCE(field347, ''), COALESCE(field348, ''), COALESCE(field349, ''),
               COALESCE(field354, ''), COALESCE(field355, ''), field356, field357, field358, field359, field360, field361, COALESCE(field362, ''), COALESCE(field363, ''), field364, field365, COALESCE(field373, ''), COALESCE(field374, ''),
               COALESCE(field400, ''), COALESCE(field401, ''), COALESCE(field403, ''), COALESCE(field406, ''), COALESCE(field407, ''), COALESCE(field408, ''), field415, field416, field417, COALESCE(field418, ''), field419,
               COALESCE(field440, ''), COALESCE(field442, ''), COALESCE(field443, ''),
               COALESCE(field453, ''), COALESCE(field454, ''), COALESCE(field455, ''), field456, field457, field458, field459, field460, field461, COALESCE(field462, ''), COALESCE(field463, ''), field470, field471, field472, COALESCE(field473, ''),
               COALESCE(field500, ''), COALESCE(field501, ''), COALESCE(field502, ''), COALESCE(field503, ''), COALESCE(field504, ''), COALESCE(field506, ''), COALESCE(field511, ''), COALESCE(field512, ''), COALESCE(field513, ''), COALESCE(field520, ''), COALESCE(field521, ''), COALESCE(field530, ''), COALESCE(field531, ''),
               COALESCE(field701, ''), COALESCE(field702, ''), COALESCE(field704, ''), COALESCE(field707, ''), COALESCE(field710, ''), COALESCE(field711, ''), COALESCE(field716, ''),
               COALESCE(field801, ''), COALESCE(field803, ''), COALESCE(field804, ''), field805, COALESCE(field806, ''),
               COALESCE(field901, ''), COALESCE(field903, ''), field904, COALESCE(field905, ''), COALESCE(field906, ''), COALESCE(field907, ''), COALESCE(field910, ''), field911, COALESCE(field924, ''), field926, field927, field928,
               COALESCE(field952, ''), COALESCE(field953, ''), COALESCE(field956, ''), field957, COALESCE(field958, ''), COALESCE(field959, ''), COALESCE(field963, ''), field964, field965,
               COALESCE(field982, ''), COALESCE(field983, ''), COALESCE(field984, ''), COALESCE(field985, ''), COALESCE(field986, ''), COALESCE(field987, ''), COALESCE(field988, ''), COALESCE(field989, ''), COALESCE(field990, ''), COALESCE(field991, ''), COALESCE(field992, ''), COALESCE(field993, ''), COALESCE(field994, ''), COALESCE(field995, ''), COALESCE(field996, ''), COALESCE(field997, ''), COALESCE(field998, ''), COALESCE(field999, ''),
               sfaf_record_type
        FROM sfafs
        ORDER BY created_at DESC
        LIMIT $1 OFFSET $2`

	rows, err := r.db.Query(query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to query paginated SFAF records: %w", err)
	}
	defer rows.Close()

	var sfafs []*models.SFAF
	for rows.Next() {
		var sfaf models.SFAF

		// ✅ CORRECT: Scan all individual fields directly into struct fields (Source: models.txt)
		err := rows.Scan(
			&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
			&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
			&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
			&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
			&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
			&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
			&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
			&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
			&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
			&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
			&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
			&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
			&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
			&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
			&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
			&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
			&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
			&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
			&sfaf.SFAFRecordType,
		)

		if err != nil {
			return nil, fmt.Errorf("failed to scan SFAF record: %w", err)
		}

		sfafs = append(sfafs, &sfaf)
	}

	// Check for iteration errors
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating over SFAF rows: %w", err)
	}

	return sfafs, nil
}

func (r *SFAFRepository) GetCount() (int, error) {
	var count int
	query := `SELECT COUNT(*) FROM sfafs`
	err := r.db.QueryRow(query).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("failed to count SFAF records: %w", err)
	}
	return count, nil
}

// validFieldRe matches column names like field005, field110, field999, etc.
var validFieldRe = regexp.MustCompile(`^field\d{3,4}$`)

// QueryFiltered runs server-side filtering using PostgreSQL WHERE clauses and returns
// matching SFAF records plus the total match count.
func (r *SFAFRepository) QueryFiltered(conditions []models.QueryCondition, sortField, sortOrder string, maxResults int) ([]*models.SFAF, int, error) {
	isValidField := func(f string) bool {
		return f == "created_at" || f == "sfaf_record_type" || validFieldRe.MatchString(f)
	}

	// Group conditions the same way the frontend does:
	// conditions connected by OR start a new group; within a group all are AND.
	type condGroup []models.QueryCondition
	var groups []condGroup
	var current condGroup
	for i, cond := range conditions {
		if i > 0 && strings.ToLower(cond.Connector) == "or" {
			if len(current) > 0 {
				groups = append(groups, current)
			}
			current = condGroup{}
		}
		current = append(current, cond)
	}
	if len(current) > 0 {
		groups = append(groups, current)
	}

	var args []interface{}
	argIdx := 1
	var groupSQLs []string

	for _, group := range groups {
		var condSQLs []string
		for _, cond := range group {
			if !isValidField(cond.Field) {
				continue
			}
			col := cond.Field
			val := cond.Value
			var expr string

			switch cond.Operator {
			case "equals":
				expr = fmt.Sprintf("LOWER(COALESCE(%s,'')) LIKE LOWER($%d)", col, argIdx)
				args = append(args, val+"%")
				argIdx++
			case "exact_equals":
				if val == "" {
					expr = fmt.Sprintf("(COALESCE(%s,'') = '')", col)
				} else {
					expr = fmt.Sprintf("LOWER(COALESCE(%s,'')) = LOWER($%d)", col, argIdx)
					args = append(args, val)
					argIdx++
				}
			case "not_equals":
				expr = fmt.Sprintf("LOWER(COALESCE(%s,'')) NOT LIKE LOWER($%d)", col, argIdx)
				args = append(args, val+"%")
				argIdx++
			case "contains":
				var subExprs []string
				for _, e := range strings.Split(val, ",") {
					e = strings.TrimSpace(e)
					if e != "" {
						subExprs = append(subExprs, fmt.Sprintf("LOWER(COALESCE(%s,'')) LIKE LOWER($%d)", col, argIdx))
						args = append(args, "%"+e+"%")
						argIdx++
					}
				}
				if len(subExprs) > 0 {
					expr = "(" + strings.Join(subExprs, " OR ") + ")"
				}
			case "less_than":
				expr = fmt.Sprintf("COALESCE(%s,'') < $%d", col, argIdx)
				args = append(args, val)
				argIdx++
			case "greater_than":
				expr = fmt.Sprintf("COALESCE(%s,'') > $%d", col, argIdx)
				args = append(args, val)
				argIdx++
			case "less_than_eq":
				expr = fmt.Sprintf("COALESCE(%s,'') <= $%d", col, argIdx)
				args = append(args, val)
				argIdx++
			case "greater_than_eq":
				expr = fmt.Sprintf("COALESCE(%s,'') >= $%d", col, argIdx)
				args = append(args, val)
				argIdx++
			case "in":
				var inExprs []string
				for _, entry := range strings.Split(val, ",") {
					entry = strings.TrimSpace(entry)
					if entry != "" {
						inExprs = append(inExprs, fmt.Sprintf("LOWER(COALESCE(%s,'')) LIKE LOWER($%d)", col, argIdx))
						args = append(args, entry+"%")
						argIdx++
					}
				}
				if len(inExprs) > 0 {
					expr = "(" + strings.Join(inExprs, " OR ") + ")"
				}
			case "between":
				parts := strings.SplitN(val, "..", 2)
				if len(parts) == 2 {
					low := strings.TrimSpace(parts[0])
					high := strings.TrimSpace(parts[1])
					expr = fmt.Sprintf("COALESCE(%s,'') >= $%d AND COALESCE(%s,'') <= $%d", col, argIdx, col, argIdx+1)
					args = append(args, low, high)
					argIdx += 2
				}
			// "contained_in" ($) is not supported server-side; falls through with no expr.
			}

			if expr != "" {
				if cond.Negate {
					expr = "NOT (" + expr + ")"
				}
				condSQLs = append(condSQLs, expr)
			}
		}
		if len(condSQLs) > 0 {
			groupSQLs = append(groupSQLs, "("+strings.Join(condSQLs, " AND ")+")")
		}
	}

	if len(groupSQLs) == 0 {
		// Every supplied condition was either unsupported server-side (e.g.
		// "contained_in") or had an invalid field/value — return nothing rather
		// than a full table scan.
		return []*models.SFAF{}, 0, nil
	}
	whereSQL := "WHERE " + strings.Join(groupSQLs, " OR ")

	// Validate sort field to prevent injection
	sortMap := map[string]string{
		"created_at": "created_at",
		"frequency":  "field110",
		"serial":     "field102",
		"location":   "field301",
	}
	dbSort, ok := sortMap[sortField]
	if !ok {
		if validFieldRe.MatchString(sortField) || sortField == "sfaf_record_type" {
			dbSort = sortField
		} else {
			dbSort = "created_at"
		}
	}
	if sortOrder != "asc" && sortOrder != "desc" {
		sortOrder = "asc"
	}
	if maxResults < 1 || maxResults > 10000 {
		maxResults = 5000
	}

	// Count matching records
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM sfafs %s", whereSQL)
	var total int
	if err := r.db.QueryRow(countQuery, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("failed to count query results: %w", err)
	}

	// Fetch matching records (capped at maxResults)
	dataArgs := append(append([]interface{}{}, args...), maxResults)
	dataQuery := fmt.Sprintf(`
        SELECT id, marker_id, created_at, updated_at,
               COALESCE(field005, ''), COALESCE(field006, ''), COALESCE(field007, ''), COALESCE(field010, ''), COALESCE(field013, ''), COALESCE(field014, ''), COALESCE(field015, ''), COALESCE(field016, ''), COALESCE(field017, ''), COALESCE(field018, ''), COALESCE(field019, ''), COALESCE(field020, ''),
               COALESCE(field102, ''), COALESCE(field103, ''), COALESCE(field105, ''), COALESCE(field106, ''), COALESCE(field107, ''), COALESCE(field108, ''), COALESCE(field110, ''), COALESCE(field111, ''), COALESCE(field112, ''), COALESCE(field113, ''), COALESCE(field114, ''), COALESCE(field115, ''), COALESCE(field116, ''), COALESCE(field117, ''), COALESCE(field118, ''),
               COALESCE(field130, ''), COALESCE(field131, ''), field140, field141, field142, field143, COALESCE(field144, ''), COALESCE(field145, ''), COALESCE(field146, ''), COALESCE(field147, ''), COALESCE(field151, ''), COALESCE(field152, ''),
               COALESCE(field200, ''), COALESCE(field201, ''), COALESCE(field202, ''), COALESCE(field203, ''), COALESCE(field204, ''), COALESCE(field205, ''), COALESCE(field206, ''), COALESCE(field207, ''), COALESCE(field208, ''), COALESCE(field209, ''),
               COALESCE(field300, ''), COALESCE(field301, ''), COALESCE(field302, ''), COALESCE(field303, ''), COALESCE(field304, ''), COALESCE(field306, ''),
               field315, field316, field317, COALESCE(field318, ''), field319, field321,
               COALESCE(field340, ''), COALESCE(field341, ''), COALESCE(field342, ''), COALESCE(field343, ''), COALESCE(field344, ''), COALESCE(field345, ''), COALESCE(field346, ''), COALESCE(field347, ''), COALESCE(field348, ''), COALESCE(field349, ''),
               COALESCE(field354, ''), COALESCE(field355, ''), field356, field357, field358, field359, field360, field361, COALESCE(field362, ''), COALESCE(field363, ''), field364, field365, COALESCE(field373, ''), COALESCE(field374, ''),
               COALESCE(field400, ''), COALESCE(field401, ''), COALESCE(field403, ''), COALESCE(field406, ''), COALESCE(field407, ''), COALESCE(field408, ''), field415, field416, field417, COALESCE(field418, ''), field419,
               COALESCE(field440, ''), COALESCE(field442, ''), COALESCE(field443, ''),
               COALESCE(field453, ''), COALESCE(field454, ''), COALESCE(field455, ''), field456, field457, field458, field459, field460, field461, COALESCE(field462, ''), COALESCE(field463, ''), field470, field471, field472, COALESCE(field473, ''),
               COALESCE(field500, ''), COALESCE(field501, ''), COALESCE(field502, ''), COALESCE(field503, ''), COALESCE(field504, ''), COALESCE(field506, ''), COALESCE(field511, ''), COALESCE(field512, ''), COALESCE(field513, ''), COALESCE(field520, ''), COALESCE(field521, ''), COALESCE(field530, ''), COALESCE(field531, ''),
               COALESCE(field701, ''), COALESCE(field702, ''), COALESCE(field704, ''), COALESCE(field707, ''), COALESCE(field710, ''), COALESCE(field711, ''), COALESCE(field716, ''),
               COALESCE(field801, ''), COALESCE(field803, ''), COALESCE(field804, ''), field805, COALESCE(field806, ''),
               COALESCE(field901, ''), COALESCE(field903, ''), field904, COALESCE(field905, ''), COALESCE(field906, ''), COALESCE(field907, ''), COALESCE(field910, ''), field911, COALESCE(field924, ''), field926, field927, field928,
               COALESCE(field952, ''), COALESCE(field953, ''), COALESCE(field956, ''), field957, COALESCE(field958, ''), COALESCE(field959, ''), COALESCE(field963, ''), field964, field965,
               COALESCE(field982, ''), COALESCE(field983, ''), COALESCE(field984, ''), COALESCE(field985, ''), COALESCE(field986, ''), COALESCE(field987, ''), COALESCE(field988, ''), COALESCE(field989, ''), COALESCE(field990, ''), COALESCE(field991, ''), COALESCE(field992, ''), COALESCE(field993, ''), COALESCE(field994, ''), COALESCE(field995, ''), COALESCE(field996, ''), COALESCE(field997, ''), COALESCE(field998, ''), COALESCE(field999, ''),
               sfaf_record_type
        FROM sfafs
        %s
        ORDER BY %s %s
        LIMIT $%d`, whereSQL, dbSort, sortOrder, argIdx)

	rows, err := r.db.Query(dataQuery, dataArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to execute query: %w", err)
	}
	defer rows.Close()

	var sfafs []*models.SFAF
	for rows.Next() {
		var sfaf models.SFAF
		err := rows.Scan(
			&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
			&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
			&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
			&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
			&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
			&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
			&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
			&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
			&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
			&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
			&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
			&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
			&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
			&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
			&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
			&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
			&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
			&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
			&sfaf.SFAFRecordType,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan query result: %w", err)
		}
		sfafs = append(sfafs, &sfaf)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("error iterating query results: %w", err)
	}
	return sfafs, total, nil
}

// CreateSFAFField inserts a multi-occurrence field into the sfaf_fields table
func (r *SFAFRepository) CreateSFAFField(field *models.SFAFField) error {
	query := `INSERT INTO sfaf_fields (id, marker_id, field_number, field_value, occurrence_number, created_at)
	          VALUES ($1, $2, $3, $4, $5, $6)`
	_, err := r.db.Exec(query,
		field.ID, field.MarkerID, field.FieldNumber,
		field.FieldValue, field.OccurrenceNumber, field.CreatedAt)
	return err
}

// GetAllWithMarkers returns all SFAF records joined with their marker coordinates via LEFT JOIN.
// Records without a marker get HasCoords=false and Latitude/Longitude=0.
func (r *SFAFRepository) GetAllWithMarkers() ([]*models.SFAFGeo, error) {
	query := `
        SELECT
            s.id, s.marker_id, s.created_at, s.updated_at,
            COALESCE(s.field005,''), COALESCE(s.field006,''), COALESCE(s.field007,''), COALESCE(s.field010,''), COALESCE(s.field013,''), COALESCE(s.field014,''), COALESCE(s.field015,''), COALESCE(s.field016,''), COALESCE(s.field017,''), COALESCE(s.field018,''), COALESCE(s.field019,''), COALESCE(s.field020,''),
            COALESCE(s.field102,''), COALESCE(s.field103,''), COALESCE(s.field105,''), COALESCE(s.field106,''), COALESCE(s.field107,''), COALESCE(s.field108,''), COALESCE(s.field110,''), COALESCE(s.field111,''), COALESCE(s.field112,''), COALESCE(s.field113,''), COALESCE(s.field114,''), COALESCE(s.field115,''), COALESCE(s.field116,''), COALESCE(s.field117,''), COALESCE(s.field118,''),
            COALESCE(s.field130,''), COALESCE(s.field131,''), s.field140, s.field141, s.field142, s.field143, COALESCE(s.field144,''), COALESCE(s.field145,''), COALESCE(s.field146,''), COALESCE(s.field147,''), COALESCE(s.field151,''), COALESCE(s.field152,''),
            COALESCE(s.field200,''), COALESCE(s.field201,''), COALESCE(s.field202,''), COALESCE(s.field203,''), COALESCE(s.field204,''), COALESCE(s.field205,''), COALESCE(s.field206,''), COALESCE(s.field207,''), COALESCE(s.field208,''), COALESCE(s.field209,''),
            COALESCE(s.field300,''), COALESCE(s.field301,''), COALESCE(s.field302,''), COALESCE(s.field303,''), COALESCE(s.field304,''), COALESCE(s.field306,''),
            s.field315, s.field316, s.field317, COALESCE(s.field318,''), s.field319, s.field321,
            COALESCE(s.field340,''), COALESCE(s.field341,''), COALESCE(s.field342,''), COALESCE(s.field343,''), COALESCE(s.field344,''), COALESCE(s.field345,''), COALESCE(s.field346,''), COALESCE(s.field347,''), COALESCE(s.field348,''), COALESCE(s.field349,''),
            COALESCE(s.field354,''), COALESCE(s.field355,''), s.field356, s.field357, s.field358, s.field359, s.field360, s.field361, COALESCE(s.field362,''), COALESCE(s.field363,''), s.field364, s.field365, COALESCE(s.field373,''), COALESCE(s.field374,''),
            COALESCE(s.field400,''), COALESCE(s.field401,''), COALESCE(s.field403,''), COALESCE(s.field406,''), COALESCE(s.field407,''), COALESCE(s.field408,''), s.field415, s.field416, s.field417, COALESCE(s.field418,''), s.field419,
            COALESCE(s.field440,''), COALESCE(s.field442,''), COALESCE(s.field443,''),
            COALESCE(s.field453,''), COALESCE(s.field454,''), COALESCE(s.field455,''), s.field456, s.field457, s.field458, s.field459, s.field460, s.field461, COALESCE(s.field462,''), COALESCE(s.field463,''), s.field470, s.field471, s.field472, COALESCE(s.field473,''),
            COALESCE(s.field500,''), COALESCE(s.field501,''), COALESCE(s.field502,''), COALESCE(s.field503,''), COALESCE(s.field504,''), COALESCE(s.field506,''), COALESCE(s.field511,''), COALESCE(s.field512,''), COALESCE(s.field513,''), COALESCE(s.field520,''), COALESCE(s.field521,''), COALESCE(s.field530,''), COALESCE(s.field531,''),
            COALESCE(s.field701,''), COALESCE(s.field702,''), COALESCE(s.field704,''), COALESCE(s.field707,''), COALESCE(s.field710,''), COALESCE(s.field711,''), COALESCE(s.field716,''),
            COALESCE(s.field801,''), COALESCE(s.field803,''), COALESCE(s.field804,''), s.field805, COALESCE(s.field806,''),
            COALESCE(s.field901,''), COALESCE(s.field903,''), s.field904, COALESCE(s.field905,''), COALESCE(s.field906,''), COALESCE(s.field907,''), COALESCE(s.field910,''), s.field911, COALESCE(s.field924,''), s.field926, s.field927, s.field928,
            COALESCE(s.field952,''), COALESCE(s.field953,''), COALESCE(s.field956,''), s.field957, COALESCE(s.field958,''), COALESCE(s.field959,''), COALESCE(s.field963,''), s.field964, s.field965,
            COALESCE(s.field982,''), COALESCE(s.field983,''), COALESCE(s.field984,''), COALESCE(s.field985,''), COALESCE(s.field986,''), COALESCE(s.field987,''), COALESCE(s.field988,''), COALESCE(s.field989,''), COALESCE(s.field990,''), COALESCE(s.field991,''), COALESCE(s.field992,''), COALESCE(s.field993,''), COALESCE(s.field994,''), COALESCE(s.field995,''), COALESCE(s.field996,''), COALESCE(s.field997,''), COALESCE(s.field998,''), COALESCE(s.field999,''),
            (m.id IS NOT NULL) AS has_marker,
            COALESCE(m.latitude,  0.0) AS marker_lat,
            COALESCE(m.longitude, 0.0) AS marker_lng
        FROM sfafs s
        LEFT JOIN markers m ON s.marker_id = m.id
        ORDER BY s.created_at DESC`

	rows, err := r.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("failed to query SFAF records for EW analysis: %w", err)
	}
	defer rows.Close()

	var sfafs []*models.SFAFGeo
	for rows.Next() {
		var sfaf models.SFAF
		var hasMarker bool
		var markerLat, markerLng float64

		err := rows.Scan(
			&sfaf.ID, &sfaf.MarkerID, &sfaf.CreatedAt, &sfaf.UpdatedAt,
			&sfaf.Field005, &sfaf.Field006, &sfaf.Field007, &sfaf.Field010, &sfaf.Field013, &sfaf.Field014, &sfaf.Field015, &sfaf.Field016, &sfaf.Field017, &sfaf.Field018, &sfaf.Field019, &sfaf.Field020,
			&sfaf.Field102, &sfaf.Field103, &sfaf.Field105, &sfaf.Field106, &sfaf.Field107, &sfaf.Field108, &sfaf.Field110, &sfaf.Field111, &sfaf.Field112, &sfaf.Field113, &sfaf.Field114, &sfaf.Field115, &sfaf.Field116, &sfaf.Field117, &sfaf.Field118,
			&sfaf.Field130, &sfaf.Field131, &sfaf.Field140, &sfaf.Field141, &sfaf.Field142, &sfaf.Field143, &sfaf.Field144, &sfaf.Field145, &sfaf.Field146, &sfaf.Field147, &sfaf.Field151, &sfaf.Field152,
			&sfaf.Field200, &sfaf.Field201, &sfaf.Field202, &sfaf.Field203, &sfaf.Field204, &sfaf.Field205, &sfaf.Field206, &sfaf.Field207, &sfaf.Field208, &sfaf.Field209,
			&sfaf.Field300, &sfaf.Field301, &sfaf.Field302, &sfaf.Field303, &sfaf.Field304, &sfaf.Field306,
			&sfaf.Field315, &sfaf.Field316, &sfaf.Field317, &sfaf.Field318, &sfaf.Field319, &sfaf.Field321,
			&sfaf.Field340, &sfaf.Field341, &sfaf.Field342, &sfaf.Field343, &sfaf.Field344, &sfaf.Field345, &sfaf.Field346, &sfaf.Field347, &sfaf.Field348, &sfaf.Field349,
			&sfaf.Field354, &sfaf.Field355, &sfaf.Field356, &sfaf.Field357, &sfaf.Field358, &sfaf.Field359, &sfaf.Field360, &sfaf.Field361, &sfaf.Field362, &sfaf.Field363, &sfaf.Field364, &sfaf.Field365, &sfaf.Field373, &sfaf.Field374,
			&sfaf.Field400, &sfaf.Field401, &sfaf.Field403, &sfaf.Field406, &sfaf.Field407, &sfaf.Field408, &sfaf.Field415, &sfaf.Field416, &sfaf.Field417, &sfaf.Field418, &sfaf.Field419,
			&sfaf.Field440, &sfaf.Field442, &sfaf.Field443,
			&sfaf.Field453, &sfaf.Field454, &sfaf.Field455, &sfaf.Field456, &sfaf.Field457, &sfaf.Field458, &sfaf.Field459, &sfaf.Field460, &sfaf.Field461, &sfaf.Field462, &sfaf.Field463, &sfaf.Field470, &sfaf.Field471, &sfaf.Field472, &sfaf.Field473,
			&sfaf.Field500, &sfaf.Field501, &sfaf.Field502, &sfaf.Field503, &sfaf.Field504, &sfaf.Field506, &sfaf.Field511, &sfaf.Field512, &sfaf.Field513, &sfaf.Field520, &sfaf.Field521, &sfaf.Field530, &sfaf.Field531,
			&sfaf.Field701, &sfaf.Field702, &sfaf.Field704, &sfaf.Field707, &sfaf.Field710, &sfaf.Field711, &sfaf.Field716,
			&sfaf.Field801, &sfaf.Field803, &sfaf.Field804, &sfaf.Field805, &sfaf.Field806,
			&sfaf.Field901, &sfaf.Field903, &sfaf.Field904, &sfaf.Field905, &sfaf.Field906, &sfaf.Field907, &sfaf.Field910, &sfaf.Field911, &sfaf.Field924, &sfaf.Field926, &sfaf.Field927, &sfaf.Field928,
			&sfaf.Field952, &sfaf.Field953, &sfaf.Field956, &sfaf.Field957, &sfaf.Field958, &sfaf.Field959, &sfaf.Field963, &sfaf.Field964, &sfaf.Field965,
			&sfaf.Field982, &sfaf.Field983, &sfaf.Field984, &sfaf.Field985, &sfaf.Field986, &sfaf.Field987, &sfaf.Field988, &sfaf.Field989, &sfaf.Field990, &sfaf.Field991, &sfaf.Field992, &sfaf.Field993, &sfaf.Field994, &sfaf.Field995, &sfaf.Field996, &sfaf.Field997, &sfaf.Field998, &sfaf.Field999,
			&hasMarker, &markerLat, &markerLng,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan SFAF/marker row: %w", err)
		}
		sfafs = append(sfafs, &models.SFAFGeo{
			SFAF:      &sfaf,
			Latitude:  markerLat,
			Longitude: markerLng,
			HasCoords: hasMarker,
		})
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("row iteration error in GetAllWithMarkers: %w", err)
	}
	return sfafs, nil
}

// GetSFAFFieldsByMarkerAndField retrieves all occurrences of a specific field for a marker
// Used for Field 530 polygon coordinates (530, 530/2, 530/3, etc.)
func (r *SFAFRepository) GetSFAFFieldsByMarkerAndField(markerID uuid.UUID, fieldNumber string) ([]models.SFAFField, error) {
	query := `
		SELECT id, marker_id, field_number, field_value, occurrence_number, created_at
		FROM sfaf_fields
		WHERE marker_id = $1 AND field_number = $2
		ORDER BY occurrence_number ASC
	`
	var fields []models.SFAFField
	err := r.db.Select(&fields, query, markerID, fieldNumber)
	return fields, err
}

// GetMarkersWithField retrieves all marker IDs that have a specific field number
// Used to find all markers with Field 530 polygon data
func (r *SFAFRepository) GetMarkersWithField(fieldNumber string) ([]uuid.UUID, error) {
	query := `
		SELECT DISTINCT marker_id
		FROM sfaf_fields
		WHERE field_number = $1
		ORDER BY marker_id
	`
	var markerIDs []uuid.UUID
	err := r.db.Select(&markerIDs, query, fieldNumber)
	return markerIDs, err
}

// GetMarkerByID retrieves a marker by its ID
// Used to get marker details (serial number, etc.) for polygon responses
func (r *SFAFRepository) GetMarkerByID(markerID uuid.UUID) (*models.Marker, error) {
	var marker models.Marker
	query := `
		SELECT id, serial, latitude, longitude, frequency, notes, marker_type,
		       is_draggable, created_at, updated_at
		FROM markers
		WHERE id = $1
	`
	err := r.db.Get(&marker, query, markerID)
	return &marker, err
}

// BatchCreate inserts each SFAF record individually. It returns a slice of errors
// (one per input, nil on success) so callers can skip failed records and continue.
func (r *SFAFRepository) BatchCreate(sfafs []*models.SFAF) []error {
	errs := make([]error, len(sfafs))
	now := time.Now()
	for i, sfaf := range sfafs {
		if sfaf.ID == uuid.Nil {
			sfaf.ID = uuid.New()
		}
		sfaf.CreatedAt = now
		sfaf.UpdatedAt = now

		tx, err := r.db.Beginx()
		if err != nil {
			errs[i] = fmt.Errorf("failed to begin transaction: %w", err)
			continue
		}
		err = r.execCreateInTransaction(tx, sfaf)
		if err != nil {
			tx.Rollback()
			errs[i] = err
			continue
		}
		if err = tx.Commit(); err != nil {
			errs[i] = fmt.Errorf("failed to commit: %w", err)
		}
	}
	return errs
}

// execCreateInTransaction performs the actual insert within a transaction
func (r *SFAFRepository) execCreateInTransaction(tx *sqlx.Tx, sfaf *models.SFAF) error {
	query := `
        INSERT INTO sfafs (
            id, marker_id, created_at, updated_at,
            field005, field006, field007, field010, field013, field014, field015, field016, field017, field018, field019, field020,
            field102, field103, field105, field106, field107, field108,
            field110, field111, field112, field113, field114, field115, field116, field117, field118,
            field130, field131, field140, field141, field142, field143, field144, field145, field146, field147, field151, field152,
            field200, field201, field202, field203, field204, field205, field206, field207, field208, field209,
            field300, field301, field302, field303, field304, field306,
            field315, field316, field317, field318, field319, field321,
            field340, field341, field342, field343, field344, field345, field346, field347, field348, field349,
            field354, field355, field356, field357, field358, field359, field360, field361, field362, field363, field364, field365, field373, field374,
            field400, field401, field403, field406, field407, field408,
            field415, field416, field417, field418, field419,
            field440, field442, field443,
            field453, field454, field455, field456, field457, field458, field459, field460, field461, field462, field463, field470, field471, field472, field473,
            field500, field501, field502, field503, field504, field506, field511, field512, field513, field520, field521, field530, field531,
            field701, field702, field704, field707, field710, field711, field716,
            field801, field803, field804, field805, field806,
            field901, field903, field904, field905, field906, field907, field910, field911, field924, field926, field927, field928,
            field952, field953, field956, field957, field958, field959, field963, field964, field965,
            field990, field991
        ) VALUES (
            $1, $2, $3, $4,
            $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
            $17, $18, $19, $20, $21, $22,
            $23, $24, $25, $26, $27, $28, $29, $30, $31,
            $32, $33, $34, $35, $36, $37, $38, $39, $40, $41, $42, $43,
            $44, $45, $46, $47, $48, $49, $50, $51, $52, $53,
            $54, $55, $56, $57, $58, $59,
            $60, $61, $62, $63, $64, $65,
            $66, $67, $68, $69, $70, $71, $72, $73, $74, $75,
            $76, $77, $78, $79, $80, $81, $82, $83, $84, $85, $86, $87, $88, $89,
            $90, $91, $92, $93, $94, $95,
            $96, $97, $98, $99, $100,
            $101, $102, $103,
            $104, $105, $106, $107, $108, $109, $110, $111, $112, $113, $114, $115, $116, $117, $118,
            $119, $120, $121, $122, $123, $124, $125, $126, $127, $128, $129, $130, $131,
            $132, $133, $134, $135, $136, $137, $138,
            $139, $140, $141, $142, $143,
            $144, $145, $146, $147, $148, $149, $150, $151, $152, $153, $154, $155,
            $156, $157, $158, $159, $160, $161, $162, $163, $164,
            $165, $166
        )
        ON CONFLICT (field102) WHERE field102 IS NOT NULL DO UPDATE SET
            marker_id = EXCLUDED.marker_id,
            updated_at = EXCLUDED.updated_at,
            field005 = EXCLUDED.field005,
            field006 = EXCLUDED.field006,
            field007 = EXCLUDED.field007,
            field010 = EXCLUDED.field010,
            field013 = EXCLUDED.field013,
            field014 = EXCLUDED.field014,
            field015 = EXCLUDED.field015,
            field016 = EXCLUDED.field016,
            field017 = EXCLUDED.field017,
            field018 = EXCLUDED.field018,
            field019 = EXCLUDED.field019,
            field020 = EXCLUDED.field020,
            field102 = EXCLUDED.field102,
            field103 = EXCLUDED.field103,
            field105 = EXCLUDED.field105,
            field106 = EXCLUDED.field106,
            field107 = EXCLUDED.field107,
            field108 = EXCLUDED.field108,
            field110 = EXCLUDED.field110,
            field111 = EXCLUDED.field111,
            field112 = EXCLUDED.field112,
            field113 = EXCLUDED.field113,
            field114 = EXCLUDED.field114,
            field115 = EXCLUDED.field115,
            field116 = EXCLUDED.field116,
            field117 = EXCLUDED.field117,
            field118 = EXCLUDED.field118,
            field130 = EXCLUDED.field130,
            field131 = EXCLUDED.field131,
            field140 = EXCLUDED.field140,
            field141 = EXCLUDED.field141,
            field142 = EXCLUDED.field142,
            field143 = EXCLUDED.field143,
            field144 = EXCLUDED.field144,
            field145 = EXCLUDED.field145,
            field146 = EXCLUDED.field146,
            field147 = EXCLUDED.field147,
            field151 = EXCLUDED.field151,
            field152 = EXCLUDED.field152,
            field200 = EXCLUDED.field200,
            field201 = EXCLUDED.field201,
            field202 = EXCLUDED.field202,
            field203 = EXCLUDED.field203,
            field204 = EXCLUDED.field204,
            field205 = EXCLUDED.field205,
            field206 = EXCLUDED.field206,
            field207 = EXCLUDED.field207,
            field208 = EXCLUDED.field208,
            field209 = EXCLUDED.field209,
            field300 = EXCLUDED.field300,
            field301 = EXCLUDED.field301,
            field302 = EXCLUDED.field302,
            field303 = EXCLUDED.field303,
            field304 = EXCLUDED.field304,
            field306 = EXCLUDED.field306,
            field315 = EXCLUDED.field315,
            field316 = EXCLUDED.field316,
            field317 = EXCLUDED.field317,
            field318 = EXCLUDED.field318,
            field319 = EXCLUDED.field319,
            field321 = EXCLUDED.field321,
            field340 = EXCLUDED.field340,
            field341 = EXCLUDED.field341,
            field342 = EXCLUDED.field342,
            field343 = EXCLUDED.field343,
            field344 = EXCLUDED.field344,
            field345 = EXCLUDED.field345,
            field346 = EXCLUDED.field346,
            field347 = EXCLUDED.field347,
            field348 = EXCLUDED.field348,
            field349 = EXCLUDED.field349,
            field354 = EXCLUDED.field354,
            field355 = EXCLUDED.field355,
            field356 = EXCLUDED.field356,
            field357 = EXCLUDED.field357,
            field358 = EXCLUDED.field358,
            field359 = EXCLUDED.field359,
            field360 = EXCLUDED.field360,
            field361 = EXCLUDED.field361,
            field362 = EXCLUDED.field362,
            field363 = EXCLUDED.field363,
            field364 = EXCLUDED.field364,
            field365 = EXCLUDED.field365,
            field373 = EXCLUDED.field373,
            field374 = EXCLUDED.field374,
            field400 = EXCLUDED.field400,
            field401 = EXCLUDED.field401,
            field403 = EXCLUDED.field403,
            field406 = EXCLUDED.field406,
            field407 = EXCLUDED.field407,
            field408 = EXCLUDED.field408,
            field415 = EXCLUDED.field415,
            field416 = EXCLUDED.field416,
            field417 = EXCLUDED.field417,
            field418 = EXCLUDED.field418,
            field419 = EXCLUDED.field419,
            field440 = EXCLUDED.field440,
            field442 = EXCLUDED.field442,
            field443 = EXCLUDED.field443,
            field453 = EXCLUDED.field453,
            field454 = EXCLUDED.field454,
            field455 = EXCLUDED.field455,
            field456 = EXCLUDED.field456,
            field457 = EXCLUDED.field457,
            field458 = EXCLUDED.field458,
            field459 = EXCLUDED.field459,
            field460 = EXCLUDED.field460,
            field461 = EXCLUDED.field461,
            field462 = EXCLUDED.field462,
            field463 = EXCLUDED.field463,
            field470 = EXCLUDED.field470,
            field471 = EXCLUDED.field471,
            field472 = EXCLUDED.field472,
            field473 = EXCLUDED.field473,
            field500 = EXCLUDED.field500,
            field501 = EXCLUDED.field501,
            field502 = EXCLUDED.field502,
            field503 = EXCLUDED.field503,
            field504 = EXCLUDED.field504,
            field506 = EXCLUDED.field506,
            field511 = EXCLUDED.field511,
            field512 = EXCLUDED.field512,
            field513 = EXCLUDED.field513,
            field520 = EXCLUDED.field520,
            field521 = EXCLUDED.field521,
            field530 = EXCLUDED.field530,
            field531 = EXCLUDED.field531,
            field701 = EXCLUDED.field701,
            field702 = EXCLUDED.field702,
            field704 = EXCLUDED.field704,
            field707 = EXCLUDED.field707,
            field710 = EXCLUDED.field710,
            field711 = EXCLUDED.field711,
            field716 = EXCLUDED.field716,
            field801 = EXCLUDED.field801,
            field803 = EXCLUDED.field803,
            field804 = EXCLUDED.field804,
            field805 = EXCLUDED.field805,
            field806 = EXCLUDED.field806,
            field901 = EXCLUDED.field901,
            field903 = EXCLUDED.field903,
            field904 = EXCLUDED.field904,
            field905 = EXCLUDED.field905,
            field906 = EXCLUDED.field906,
            field907 = EXCLUDED.field907,
            field910 = EXCLUDED.field910,
            field911 = EXCLUDED.field911,
            field924 = EXCLUDED.field924,
            field926 = EXCLUDED.field926,
            field927 = EXCLUDED.field927,
            field928 = EXCLUDED.field928,
            field952 = EXCLUDED.field952,
            field953 = EXCLUDED.field953,
            field956 = EXCLUDED.field956,
            field957 = EXCLUDED.field957,
            field958 = EXCLUDED.field958,
            field959 = EXCLUDED.field959,
            field963 = EXCLUDED.field963,
            field964 = EXCLUDED.field964,
            field965 = EXCLUDED.field965,
            field990 = EXCLUDED.field990,
            field991 = EXCLUDED.field991
    `

	_, err := tx.Exec(query,
		sfaf.ID, sfaf.MarkerID, sfaf.CreatedAt, sfaf.UpdatedAt,
		sfaf.Field005, sfaf.Field006, sfaf.Field007, sfaf.Field010, sfaf.Field013, sfaf.Field014, sfaf.Field015, sfaf.Field016, sfaf.Field017, sfaf.Field018, sfaf.Field019, sfaf.Field020,
		sfaf.Field102, sfaf.Field103, sfaf.Field105, sfaf.Field106, sfaf.Field107, sfaf.Field108,
		sfaf.Field110, sfaf.Field111, sfaf.Field112, sfaf.Field113, sfaf.Field114, sfaf.Field115, sfaf.Field116, sfaf.Field117, sfaf.Field118,
		sfaf.Field130, sfaf.Field131, sfaf.Field140, sfaf.Field141, sfaf.Field142, sfaf.Field143, sfaf.Field144, sfaf.Field145, sfaf.Field146, sfaf.Field147, sfaf.Field151, sfaf.Field152,
		sfaf.Field200, sfaf.Field201, sfaf.Field202, sfaf.Field203, sfaf.Field204, sfaf.Field205, sfaf.Field206, sfaf.Field207, sfaf.Field208, sfaf.Field209,
		sfaf.Field300, sfaf.Field301, sfaf.Field302, sfaf.Field303, sfaf.Field304, sfaf.Field306,
		sfaf.Field315, sfaf.Field316, sfaf.Field317, sfaf.Field318, sfaf.Field319, sfaf.Field321,
		sfaf.Field340, sfaf.Field341, sfaf.Field342, sfaf.Field343, sfaf.Field344, sfaf.Field345, sfaf.Field346, sfaf.Field347, sfaf.Field348, sfaf.Field349,
		sfaf.Field354, sfaf.Field355, sfaf.Field356, sfaf.Field357, sfaf.Field358, sfaf.Field359, sfaf.Field360, sfaf.Field361, sfaf.Field362, sfaf.Field363, sfaf.Field364, sfaf.Field365, sfaf.Field373, sfaf.Field374,
		sfaf.Field400, sfaf.Field401, sfaf.Field403, sfaf.Field406, sfaf.Field407, sfaf.Field408,
		sfaf.Field415, sfaf.Field416, sfaf.Field417, sfaf.Field418, sfaf.Field419,
		sfaf.Field440, sfaf.Field442, sfaf.Field443,
		sfaf.Field453, sfaf.Field454, sfaf.Field455, sfaf.Field456, sfaf.Field457, sfaf.Field458, sfaf.Field459, sfaf.Field460, sfaf.Field461, sfaf.Field462, sfaf.Field463, sfaf.Field470, sfaf.Field471, sfaf.Field472, sfaf.Field473,
		sfaf.Field500, sfaf.Field501, sfaf.Field502, sfaf.Field503, sfaf.Field504, sfaf.Field506, sfaf.Field511, sfaf.Field512, sfaf.Field513, sfaf.Field520, sfaf.Field521, sfaf.Field530, sfaf.Field531,
		sfaf.Field701, sfaf.Field702, sfaf.Field704, sfaf.Field707, sfaf.Field710, sfaf.Field711, sfaf.Field716,
		sfaf.Field801, sfaf.Field803, sfaf.Field804, sfaf.Field805, sfaf.Field806,
		sfaf.Field901, sfaf.Field903, sfaf.Field904, sfaf.Field905, sfaf.Field906, sfaf.Field907, sfaf.Field910, sfaf.Field911, sfaf.Field924, sfaf.Field926, sfaf.Field927, sfaf.Field928,
		sfaf.Field952, sfaf.Field953, sfaf.Field956, sfaf.Field957, sfaf.Field958, sfaf.Field959, sfaf.Field963, sfaf.Field964, sfaf.Field965,
		sfaf.Field990, sfaf.Field991,
	)

	return err
}
